#include "universal_fs.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iterator>
#include <sstream>
#include <string_view>

namespace fs = std::filesystem;

namespace deiig::ufs {
namespace {

std::string lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

std::string ext_of(const fs::path& p) {
    std::string e = p.extension().string();
    return lower(e);
}

bool has_magic(const std::array<unsigned char, 16>& b, std::size_t n, std::initializer_list<unsigned char> sig) {
    if (sig.size() > n) return false;
    std::size_t i = 0;
    for (const auto x : sig) {
        if (b[i++] != x) return false;
    }
    return true;
}

Kind extension_kind(const std::string& e) {
    if (e == ".diggcode") return Kind::DiggCode;
    if (e == ".json" || e == ".jsonc") return Kind::Json;
    if (e == ".md" || e == ".markdown") return Kind::Markdown;
    if (e == ".png" || e == ".jpg" || e == ".jpeg" || e == ".gif" || e == ".bmp" || e == ".webp" || e == ".ico") return Kind::Image;
    if (e == ".zip" || e == ".tar" || e == ".gz" || e == ".bz2" || e == ".xz" || e == ".7z") return Kind::Archive;
    if (e == ".exe" || e == ".dll" || e == ".so" || e == ".bin" || e == ".elf") return Kind::Executable;
    if (e == ".cpp" || e == ".cc" || e == ".cxx" || e == ".c" || e == ".h" || e == ".hpp" || e == ".hxx" ||
        e == ".py" || e == ".js" || e == ".ts" || e == ".java" || e == ".cs" || e == ".rs" || e == ".go" ||
        e == ".lua" || e == ".nim" || e == ".sh" || e == ".bat" || e == ".ps1" || e == ".cmake") return Kind::Source;
    if (e == ".db" || e == ".deiigdb") return Kind::Database;
    if (e == ".txt" || e == ".ini" || e == ".cfg" || e == ".toml" || e == ".yaml" || e == ".yml" ||
        e == ".xml" || e == ".csv" || e == ".log" || e == ".html" || e == ".htm" || e == ".css") return Kind::Text;
    return Kind::Unknown;
}

Kind magic_kind(const std::array<unsigned char, 16>& b, std::size_t n) {
    if (has_magic(b, n, {0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A})) return Kind::Image;
    if (has_magic(b, n, {'P', 'K', 0x03, 0x04}) || has_magic(b, n, {'P', 'K', 0x05, 0x06}) || has_magic(b, n, {'P', 'K', 0x07, 0x08})) return Kind::Archive;
    if (has_magic(b, n, {0x7F, 'E', 'L', 'F'})) return Kind::Executable;
    if (has_magic(b, n, {'M', 'Z'})) return Kind::Executable;
    if (has_magic(b, n, {'G', 'I', 'F', '8', '7', 'a'}) || has_magic(b, n, {'G', 'I', 'F', '8', '9', 'a'})) return Kind::Image;
    if (has_magic(b, n, {0xFF, 0xD8, 0xFF})) return Kind::Image;
    if (has_magic(b, n, {'B', 'M'})) return Kind::Image;
    if (has_magic(b, n, {'D', 'E', 'I', 'I', 'G', 'D', 'B', ' ' , '1'})) return Kind::Database;
    return Kind::Unknown;
}

bool utf8ish(const std::string& s) {
    std::size_t i = 0;
    std::size_t bad = 0;
    while (i < s.size()) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        if (c == 0) return false;
        if (c < 0x80) { ++i; continue; }
        std::size_t need = 0;
        if ((c & 0xE0) == 0xC0) need = 1;
        else if ((c & 0xF0) == 0xE0) need = 2;
        else if ((c & 0xF8) == 0xF0) need = 3;
        else { ++bad; ++i; continue; }
        if (i + need >= s.size()) return false;
        for (std::size_t j = 1; j <= need; ++j) {
            unsigned char cc = static_cast<unsigned char>(s[i + j]);
            if ((cc & 0xC0) != 0x80) return false;
        }
        i += need + 1;
    }
    return bad == 0;
}

} // namespace

std::string kind_name(Kind kind) {
    switch (kind) {
        case Kind::Text: return "text";
        case Kind::Source: return "source";
        case Kind::Json: return "json";
        case Kind::Markdown: return "markdown";
        case Kind::Image: return "image";
        case Kind::Archive: return "archive";
        case Kind::Executable: return "executable";
        case Kind::Database: return "database";
        case Kind::DiggCode: return "diggcode";
        case Kind::Binary: return "binary";
        case Kind::Unknown: return "unknown";
    }
    return "unknown";
}

std::string mime_type(Kind kind) {
    switch (kind) {
        case Kind::Text: return "text/plain";
        case Kind::Source: return "text/plain";
        case Kind::Json: return "application/json";
        case Kind::Markdown: return "text/markdown";
        case Kind::Image: return "image/*";
        case Kind::Archive: return "application/archive";
        case Kind::Executable: return "application/octet-stream";
        case Kind::Database: return "application/x-deiig-db";
        case Kind::DiggCode: return "text/x-diggcode";
        default: return "application/octet-stream";
    }
}

bool is_probably_text(const fs::path& path, std::size_t sample_bytes) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::string s(sample_bytes, '\0');
    f.read(s.data(), static_cast<std::streamsize>(s.size()));
    s.resize(static_cast<std::size_t>(f.gcount()));
    if (s.empty()) return true;
    return utf8ish(s);
}

Info inspect(const fs::path& path) {
    Info info;
    std::error_code ec;
    info.path = fs::absolute(path, ec);
    info.name = path.filename().string();
    info.extension = ext_of(path);
    info.directory = fs::is_directory(path, ec);
    info.regular = fs::is_regular_file(path, ec);
    if (info.regular) info.size = fs::file_size(path, ec);
    if (info.directory) {
        info.kind = Kind::Unknown;
        info.mime = "inode/directory";
        return info;
    }

    info.kind = extension_kind(info.extension);
    std::ifstream f(path, std::ios::binary);
    if (f) {
        std::array<unsigned char, 16> b{};
        f.read(reinterpret_cast<char*>(b.data()), static_cast<std::streamsize>(b.size()));
        const std::size_t n = static_cast<std::size_t>(f.gcount());
        const Kind magic = magic_kind(b, n);
        if (magic != Kind::Unknown) info.kind = magic;
    }
    if (info.kind == Kind::Unknown && info.regular && is_probably_text(path)) info.kind = Kind::Text;
    if (info.kind == Kind::Unknown && info.regular) info.kind = Kind::Binary;
    info.mime = mime_type(info.kind);
    info.readable_text = info.kind == Kind::Text || info.kind == Kind::Source || info.kind == Kind::Json || info.kind == Kind::Markdown || info.kind == Kind::DiggCode;
    return info;
}

std::string preview_text(const fs::path& path, std::size_t max_bytes) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {};
    std::string data(max_bytes, '\0');
    f.read(data.data(), static_cast<std::streamsize>(data.size()));
    data.resize(static_cast<std::size_t>(f.gcount()));
    if (data.size() >= 3 && static_cast<unsigned char>(data[0]) == 0xEF && static_cast<unsigned char>(data[1]) == 0xBB && static_cast<unsigned char>(data[2]) == 0xBF)
        data.erase(0, 3);
    return data;
}

std::string hex_dump(const fs::path& path, std::size_t max_bytes) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {};
    std::vector<unsigned char> data(max_bytes);
    f.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(data.size()));
    data.resize(static_cast<std::size_t>(f.gcount()));

    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (std::size_t base = 0; base < data.size(); base += 16) {
        out << std::setw(8) << base << "  ";
        for (std::size_t i = 0; i < 16; ++i) {
            if (base + i < data.size()) out << std::setw(2) << static_cast<unsigned>(data[base + i]) << ' ';
            else out << "   ";
            if (i == 7) out << ' ';
        }
        out << " |";
        for (std::size_t i = 0; i < 16 && base + i < data.size(); ++i) {
            const unsigned char c = data[base + i];
            out << ((c >= 32 && c <= 126) ? static_cast<char>(c) : '.');
        }
        out << "|\n";
    }
    return out.str();
}

std::vector<fs::path> related_files(const fs::path& path) {
    std::vector<fs::path> out;
    const fs::path dir = path.parent_path();
    const std::string stem = path.stem().string();
    std::error_code ec;
    if (dir.empty() || !fs::is_directory(dir, ec)) return out;
    for (const auto& e : fs::directory_iterator(dir, fs::directory_options::skip_permission_denied, ec)) {
        if (ec) break;
        if (!e.is_regular_file(ec)) continue;
        if (e.path().stem().string() == stem && e.path() != path) out.push_back(e.path());
    }
    std::sort(out.begin(), out.end());
    return out;
}

} // namespace deiig::ufs
