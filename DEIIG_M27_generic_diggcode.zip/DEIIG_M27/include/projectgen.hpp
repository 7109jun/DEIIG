#pragma once
#include <string>
namespace deiig::projectgen { int create(const std::string&type,const std::string&dir); }
