#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace deiig::network {

struct ResolveResult {
    std::string host;
    std::vector<std::string> addresses;
    std::string error;
};

struct TcpResult {
    std::string host;
    int port = 0;
    bool connected = false;
    long long elapsed_ms = -1;
    std::string error;
};

struct HttpResult {
    int status = 0;
    std::string headers;
    std::string body;
    std::string error;
};

ResolveResult resolve(const std::string& host);
TcpResult tcp_test(const std::string& host, int port, int timeout_ms = 3000);
HttpResult http_get(const std::string& url, std::size_t max_bytes = 1024 * 1024);
int ping(const std::string& host, int count = 1);

} // namespace deiig::network
