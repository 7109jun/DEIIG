#pragma once
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

namespace deiig {
namespace fs = std::filesystem;

struct WorkflowStep {
    enum class Kind { Command, IfExists };
    Kind kind = Kind::Command;
    std::string value;
    std::string command;
};

struct WorkflowDef {
    std::string name;
    std::string description;
    bool stopOnError = true;
    std::vector<std::pair<std::string, std::string>> env;
    std::vector<WorkflowStep> steps;
};

inline std::string trim(std::string s) {
    auto notspace = [](unsigned char c) { return !std::isspace(c); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), notspace));
    s.erase(std::find_if(s.rbegin(), s.rend(), notspace).base(), s.end());
    return s;
}

inline std::vector<WorkflowDef> load_workflows(const fs::path& projectDir) {
    std::vector<WorkflowDef> out;
    std::ifstream f(projectDir / "DEIIG.workflow", std::ios::binary);
    if (!f) return out;

    WorkflowDef* current = nullptr;
    std::string line;
    while (std::getline(f, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        line = trim(line);
        if (line.empty() || line[0] == '#' || line[0] == ';') continue;

        if (line.front() == '[' && line.back() == ']') {
            std::string section = trim(line.substr(1, line.size() - 2));
            const std::string prefix = "workflow ";
            if (section.rfind(prefix, 0) == 0 && section.size() > prefix.size()) {
                out.push_back({});
                current = &out.back();
                current->name = trim(section.substr(prefix.size()));
            } else {
                current = nullptr;
            }
            continue;
        }
        if (!current) continue;
        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        const std::string key = trim(line.substr(0, eq));
        const std::string value = trim(line.substr(eq + 1));
        if (key == "description") current->description = value;
        else if (key == "stop_on_error") current->stopOnError = !(value == "false" || value == "0" || value == "no");
        else if (key == "env") {
            const auto p = value.find('=');
            if (p != std::string::npos) current->env.emplace_back(trim(value.substr(0, p)), trim(value.substr(p + 1)));
        } else if (key == "step") {
            current->steps.push_back({WorkflowStep::Kind::Command, {}, value});
        } else if (key == "step_if_exists") {
            const auto p = value.find('|');
            if (p != std::string::npos) current->steps.push_back({WorkflowStep::Kind::IfExists, trim(value.substr(0, p)), trim(value.substr(p + 1))});
        }
    }
    return out;
}

inline const WorkflowDef* find_workflow(const std::vector<WorkflowDef>& workflows, const std::string& name) {
    for (const auto& w : workflows) if (w.name == name) return &w;
    return nullptr;
}

inline std::vector<std::string> workflow_names(const std::vector<WorkflowDef>& workflows) {
    std::vector<std::string> names;
    for (const auto& w : workflows) names.push_back(w.name);
    return names;
}

} // namespace deiig
