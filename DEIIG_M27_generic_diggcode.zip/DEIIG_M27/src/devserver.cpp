#include "devserver.hpp"
#include <cstdlib>
#include <fstream>
#include <filesystem>
#ifdef _WIN32
#include <windows.h>
static PROCESS_INFORMATION gpi{};
#else
#include <unistd.h>
#include <signal.h>
#endif
namespace fs=std::filesystem;
namespace deiig::devserver {
int start(const std::string& cmd,int port){
    fs::create_directories(fs::current_path()/".deiig");
    std::ofstream(fs::current_path()/".deiig"/"devserver.profile")<<"port="<<port<<"\ncommand="<<cmd<<"\n";
#ifdef _WIN32
    STARTUPINFOA si{}; si.cb=sizeof(si); std::string c="cmd.exe /C "+cmd;
    if(!CreateProcessA(nullptr,c.data(),nullptr,nullptr,FALSE,CREATE_NEW_CONSOLE,nullptr,nullptr,&si,&gpi)) return 1;
    return 0;
#else
    std::string quoted = "'";
    for (char ch : cmd) {
        if (ch == '\'') quoted += "'\\''";
        else quoted += ch;
    }
    quoted += "'";
    std::string c = "sh -c " + quoted + " >/tmp/deiig-devserver.log 2>&1 & echo $! > .deiig/devserver.pid";
    return std::system(c.c_str());
#endif
}
int stop(){
#ifdef _WIN32
    if(!gpi.hProcess) return 1;
    TerminateProcess(gpi.hProcess,0); CloseHandle(gpi.hProcess); CloseHandle(gpi.hThread); gpi={}; return 0;
#else
    std::ifstream f(fs::current_path()/".deiig/devserver.pid"); pid_t p=0; f>>p; if(!p) return 1;
    int r=kill(p,SIGTERM); std::error_code ec; fs::remove(fs::current_path()/".deiig/devserver.pid",ec); return r;
#endif
}
int status(){
#ifdef _WIN32
    return gpi.hProcess?0:1;
#else
    std::ifstream f(fs::current_path()/".deiig/devserver.pid"); pid_t p=0; f>>p; if(!p) return 1; return kill(p,0)==0?0:1;
#endif
}
}
