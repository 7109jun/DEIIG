#include "workspace.hpp"
#include <fstream>
#include <sstream>

namespace fs = std::filesystem;
namespace deiig {

static std::string escape(const std::string& in) {
    std::string out;
    out.reserve(in.size() + 8);
    for (char c : in) {
        if (c == '\\') out += "\\\\";
        else if (c == '\n') out += "\\n";
        else out += c;
    }
    return out;
}

static std::string unescape(const std::string& in) {
    std::string out;
    bool slash = false;
    for (char c : in) {
        if (slash) {
            if (c == 'n') out += '\n'; else out += c;
            slash = false;
        } else if (c == '\\') slash = true;
        else out += c;
    }
    if (slash) out += '\\';
    return out;
}

static void write_list(std::ofstream& f, const char* key, const std::vector<std::string>& items) {
    for (const auto& item : items) f << key << '=' << escape(item) << '\n';
}

std::filesystem::path workspace_file(const fs::path& project_dir) {
    return project_dir / ".deiig" / "workspace.state";
}

bool save_workspace(const WorkspaceState& state) {
    if (state.project_dir.empty()) return false;
    std::error_code ec;
    fs::create_directories(state.project_dir / ".deiig", ec);
    if (ec) return false;
    std::ofstream f(workspace_file(state.project_dir), std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f << "DEIIG-WORKSPACE 1\n";
    f << "project=" << escape(fs::absolute(state.project_dir, ec).string()) << '\n';
    f << "current=" << escape(state.current_file.string()) << '\n';
    f << "split=" << (state.split_view ? 1 : 0) << '\n';
    f << "layout=" << state.layout_mode << '\n';
    write_list(f, "open", [&]() { std::vector<std::string> v; for (const auto& p : state.open_files) v.push_back(p.string()); return v; }());
    write_list(f, "history", state.terminal_history);
    write_list(f, "browser", state.browser_urls);
    write_list(f, "exe", state.exe_paths);
    return f.good();
}

bool load_workspace(const fs::path& project_dir, WorkspaceState& state) {
    state = {};
    std::ifstream f(workspace_file(project_dir), std::ios::binary);
    if (!f) return false;
    std::string line;
    bool header = false;
    while (std::getline(f, line)) {
        if (line == "DEIIG-WORKSPACE 1") { header = true; continue; }
        const auto pos = line.find('=');
        if (pos == std::string::npos) continue;
        const std::string key = line.substr(0, pos);
        const std::string value = unescape(line.substr(pos + 1));
        if (key == "project") state.project_dir = value;
        else if (key == "current") state.current_file = value;
        else if (key == "split") state.split_view = value == "1";
        else if (key == "layout") { try { state.layout_mode = std::stoi(value); } catch (...) { state.layout_mode = 0; } }
        else if (key == "open") state.open_files.emplace_back(value);
        else if (key == "history") state.terminal_history.push_back(value);
        else if (key == "browser") state.browser_urls.push_back(value);
        else if (key == "exe") state.exe_paths.push_back(value);
    }
    return header;
}

bool workspace_exists(const fs::path& project_dir) {
    std::error_code ec;
    return fs::is_regular_file(workspace_file(project_dir), ec);
}

} // namespace deiig
