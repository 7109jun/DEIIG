#include "browser.hpp"
#include <cstdlib>
#include <string>
#ifndef _WIN32
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif
#ifdef _WIN32
#include <windows.h>
#endif
namespace deiig::browser {
static std::string enc(const std::string& s){std::string o; const char* h="0123456789ABCDEF"; for(unsigned char c:s){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')o+=char(c);else if(c==' ')o+='+';else{o+='%';o+=h[c>>4];o+=h[c&15];}} return o;}
int open(const std::string& url){
#ifdef _WIN32
    HINSTANCE r=ShellExecuteA(nullptr,"open",url.c_str(),nullptr,nullptr,SW_SHOWNORMAL); return ((INT_PTR)r<=32)?1:0;
#else
    pid_t pid = fork();
    if (pid == -1) return 1;
    if (pid == 0) {
        execlp("xdg-open", "xdg-open", url.c_str(), static_cast<char*>(nullptr));
        _exit(127);
    }
    return 0;
#endif
}
int search(const std::string& engine,const std::string& q){std::string base=engine=="bing"?"https://www.bing.com/search?q=":"https://www.google.com/search?q=";return open(base+enc(q));}
}
