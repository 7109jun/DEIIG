# DEIIG — Milestone 10

M10 adds **DIGG Collections + Module System**.

## Collections

```digg
let nums = [10, 20, 30];
println(nums[0]);
nums[1] = 99;
array.push(nums, 40);
println(array.join(nums, ", "));

let user = {"name": "DEIIG", "version": 10};
println(user["name"]);
map.set(user, "status", "ready");
println(map.keys(user));
```

Supported collection APIs:

- `len(value)` — strings, arrays, maps
- `array.push(array, value)`
- `array.pop(array)`
- `array.join(array, separator)`
- `array.contains(array, value)`
- `map.get(map, key)`
- `map.set(map, key, value)`
- `map.has(map, key)`
- `map.keys(map)`

## Modules

Import another `.diggcode` file:

```digg
import "math_utils.diggcode";

fn main() {
    println(square(5));
}
```

Imports are resolved relative to the importing file. `.diggcode` can be omitted:

```digg
import "math_utils";
```

Modules are loaded once per runtime invocation, with simple circular-import protection.

## Build

Linux:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
./build/DIGGRuntime examples/m10_collections.diggcode
```

Windows uses the existing `build.bat` / CMake configuration.
