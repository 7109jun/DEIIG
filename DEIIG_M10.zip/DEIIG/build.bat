@echo off
setlocal

where cmake >nul 2>&1
if errorlevel 1 (
  echo CMake was not found in PATH.
  echo Run this from a Visual Studio Developer Command Prompt.
  exit /b 1
)

cmake -S . -B build -A x64
if errorlevel 1 exit /b 1

cmake --build build --config Release
if errorlevel 1 exit /b 1

echo.
echo DEIIG built successfully:
echo   build\Release\DEIIG.exe
