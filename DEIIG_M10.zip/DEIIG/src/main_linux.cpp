#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <sstream>
#include <deque>
#include <optional>
#include <unistd.h>

namespace fs = std::filesystem;

static void print_tree(const fs::path& root, int depth = 0) {
    if (depth > 2) return;
    std::vector<fs::directory_entry> items;
    std::error_code ec;
    for (fs::directory_iterator it(root, fs::directory_options::skip_permission_denied, ec), end; it != end && !ec; it.increment(ec)) {
        const auto& e = *it;
        auto name = e.path().filename().string();
        if (name == ".git" || name == "build" || name == ".vs" || name == ".idea") {
            if (e.is_directory(ec)) continue;
        }
        items.push_back(e);
    }
    std::sort(items.begin(), items.end(), [](const auto& a, const auto& b) {
        if (a.is_directory() != b.is_directory()) return a.is_directory() > b.is_directory();
        return a.path().filename().string() < b.path().filename().string();
    });
    for (const auto& e : items) {
        std::cout << std::string(depth * 2, ' ')
                  << (e.is_directory() ? "[DIR] " : "      ")
                  << e.path().filename().string() << '\n';
        if (e.is_directory()) print_tree(e.path(), depth + 1);
    }
}

static std::vector<fs::path> find_files(const fs::path& root, const std::string& needle) {
    std::vector<fs::path> hits;
    std::error_code ec;
    fs::recursive_directory_iterator it(root, fs::directory_options::skip_permission_denied), end;
    for (; it != end && !ec; it.increment(ec)) {
        const auto& e = *it;
        const auto name = e.path().filename().string();
        if (e.is_directory(ec) && (name == ".git" || name == "build" || name == ".vs" || name == ".idea")) {
            it.disable_recursion_pending();
            continue;
        }
        if (e.is_regular_file(ec) && e.path().filename().string().find(needle) != std::string::npos)
            hits.push_back(e.path());
        if (hits.size() >= 100) break;
    }
    return hits;
}

static bool write_text(const fs::path& p, const std::string& text) {
    std::error_code ec;
    if (!p.parent_path().empty()) fs::create_directories(p.parent_path(), ec);
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f << text;
    return f.good();
}

static void usage() {
    std::cout << "DEIIG 0.9 — The Development Environment Is Insanely Good\n"
                 "Linux compatibility shell. Windows GUI integrations are enabled only in the Windows build.\n\n"
                 "Commands:\n"
                 "  tree [path]        Show project tree\n"
                 "  build              Configure/build with CMake\n"
                 "  run <command>      Run a local command\n"
                 "  open <file>        Print a text file\n"
                 "  new <file>         Create a new text file\n"
                 "  find <name>        Find files by filename\n"
                 "  info               Show DEIIG/project state\n"
                 "  pwd                Show current directory\n"
                 "  help               Show this help\n"
                 "  exit               Quit\n";
}

int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--version") {
        std::cout << "DEIIG 0.9 (Linux build)\n";
        return 0;
    }

    std::cout << "DEIIG 0.9 — The Development Environment Is Insanely Good\n";
    std::cout << "Linux compatibility shell. Windows GUI features are enabled only in the Windows build.\n";
    usage();

    std::deque<std::string> history;
    std::string line;
    while (true) {
        std::cout << "\ndeiig> " << std::flush;
        if (!std::getline(std::cin, line)) break;
        if (line.empty()) continue;
        if (history.empty() || history.back() != line) history.push_back(line);
        if (history.size() > 50) history.pop_front();
        if (line == "exit" || line == "quit") break;
        if (line == "help") { usage(); continue; }
        if (line == "pwd") { std::cout << fs::current_path().string() << '\n'; continue; }
        if (line == "info") {
            std::cout << "DEIIG 0.9\nplatform: Linux compatibility\nproject: " << fs::current_path() << '\n'
                      << "history: " << history.size() << " commands\n";
            continue;
        }
        if (line == "tree") { print_tree(fs::current_path()); continue; }
        if (line.rfind("tree ", 0) == 0) { print_tree(fs::path(line.substr(5))); continue; }
        if (line == "build") {
            int rc = std::system("cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel");
            std::cout << "build exit code: " << rc << '\n';
            continue;
        }
        if (line.rfind("open ", 0) == 0) {
            fs::path p = line.substr(5);
            std::ifstream f(p);
            if (!f) { std::cerr << "cannot open: " << p << '\n'; continue; }
            std::cout << f.rdbuf() << '\n';
            continue;
        }
        if (line.rfind("new ", 0) == 0) {
            fs::path p = line.substr(4);
            if (fs::exists(p)) { std::cerr << "already exists: " << p << '\n'; continue; }
            if (!write_text(p, "// Created by DEIIG 0.8\n")) { std::cerr << "cannot create: " << p << '\n'; continue; }
            std::cout << "created: " << p << '\n';
            continue;
        }
        if (line.rfind("find ", 0) == 0) {
            auto hits = find_files(fs::current_path(), line.substr(5));
            for (const auto& p : hits) std::cout << p.string() << '\n';
            std::cout << hits.size() << " result(s)\n";
            continue;
        }
        if (line.rfind("run ", 0) == 0) {
            int rc = std::system(line.substr(4).c_str());
            std::cout << "exit code: " << rc << '\n';
            continue;
        }
        if (line.rfind("digg ", 0) == 0) {
            std::string command = "./build/DIGGRuntime \"" + line.substr(5) + "\"";
            int rc = std::system(command.c_str());
            std::cout << "DIGG exit code: " << rc << '\n';
            continue;
        }
        std::cout << "Unknown command. Type 'help'.\n";
    }
    return 0;
}
