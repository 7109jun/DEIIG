#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <chrono>
#include <thread>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace digg {

struct Value {
    enum class Type { Nil, Number, String, Bool, Array, Map } type = Type::Nil;
    double number = 0.0;
    std::string str;
    bool boolean = false;
    std::shared_ptr<std::vector<Value>> array;
    std::shared_ptr<std::map<std::string, Value>> map;

    static Value Nil() { return {}; }
    static Value Number(double v) { Value x; x.type = Type::Number; x.number = v; return x; }
    static Value String(std::string v) { Value x; x.type = Type::String; x.str = std::move(v); return x; }
    static Value Bool(bool v) { Value x; x.type = Type::Bool; x.boolean = v; return x; }
    static Value Array(std::vector<Value> v = {}) { Value x; x.type = Type::Array; x.array = std::make_shared<std::vector<Value>>(std::move(v)); return x; }
    static Value Map(std::map<std::string, Value> v = {}) { Value x; x.type = Type::Map; x.map = std::make_shared<std::map<std::string, Value>>(std::move(v)); return x; }
};

static std::string toString(const Value& v) {
    switch (v.type) {
    case Value::Type::Nil: return "nil";
    case Value::Type::Number: {
        std::ostringstream out;
        out << std::setprecision(15) << v.number;
        std::string s = out.str();
        if (s.find('.') != std::string::npos) {
            while (!s.empty() && s.back() == '0') s.pop_back();
            if (!s.empty() && s.back() == '.') s.pop_back();
        }
        return s;
    }
    case Value::Type::String: return v.str;
    case Value::Type::Bool: return v.boolean ? "true" : "false";
    case Value::Type::Array: {
        std::string out = "[";
        for (size_t i = 0; i < v.array->size(); ++i) {
            if (i) out += ", ";
            out += toString((*v.array)[i]);
        }
        return out + "]";
    }
    case Value::Type::Map: {
        std::string out = "{";
        bool first = true;
        for (const auto& [k, val] : *v.map) {
            if (!first) out += ", ";
            first = false;
            out += k + ": " + toString(val);
        }
        return out + "}";
    }
    }
    return "nil";
}

static bool truthy(const Value& v) {
    if (v.type == Value::Type::Nil) return false;
    if (v.type == Value::Type::Bool) return v.boolean;
    if (v.type == Value::Type::Number) return v.number != 0.0;
    if (v.type == Value::Type::String) return !v.str.empty();
    if (v.type == Value::Type::Array) return !v.array->empty();
    if (v.type == Value::Type::Map) return !v.map->empty();
    return false;
}

static bool equalsValue(const Value& a, const Value& b) {
    if (a.type != b.type) return false;
    switch (a.type) {
    case Value::Type::Nil: return true;
    case Value::Type::Number: return a.number == b.number;
    case Value::Type::String: return a.str == b.str;
    case Value::Type::Bool: return a.boolean == b.boolean;
    case Value::Type::Array:
        if (a.array->size() != b.array->size()) return false;
        for (size_t i = 0; i < a.array->size(); ++i) if (!equalsValue((*a.array)[i], (*b.array)[i])) return false;
        return true;
    case Value::Type::Map:
        if (a.map->size() != b.map->size()) return false;
        for (const auto& [k, v] : *a.map) {
            auto it = b.map->find(k);
            if (it == b.map->end() || !equalsValue(v, it->second)) return false;
        }
        return true;
    }
    return false;
}

struct Token {
    enum class Kind {
        End, Identifier, Number, String, LParen, RParen, LBrace, RBrace,
        LBracket, RBracket, Comma, Semicolon, Dot, Colon, Plus, Minus, Star, Slash,
        Equal, EqualEqual, BangEqual, Less, LessEqual, Greater, GreaterEqual, Bang, Keyword
    };
    Kind kind;
    std::string text;
    int line = 1;
    int column = 1;
};

class Lexer {
public:
    explicit Lexer(std::string source) : src_(std::move(source)) {}

    std::vector<Token> lex() {
        std::vector<Token> out;
        while (!atEnd()) {
            char c = advance();
            switch (c) {
            case ' ': case '\r': case '\t': break;
            case '\n': ++line_; col_ = 1; break;
            case '/':
                if (match('/')) { while (!atEnd() && peek() != '\n') advance(); }
                else if (match('*')) blockComment();
                else out.push_back(tok(Token::Kind::Slash, "/"));
                break;
            case '(': out.push_back(tok(Token::Kind::LParen, "(")); break;
            case ')': out.push_back(tok(Token::Kind::RParen, ")")); break;
            case '{': out.push_back(tok(Token::Kind::LBrace, "{")); break;
            case '}': out.push_back(tok(Token::Kind::RBrace, "}")); break;
            case '[': out.push_back(tok(Token::Kind::LBracket, "[")); break;
            case ']': out.push_back(tok(Token::Kind::RBracket, "]")); break;
            case ',': out.push_back(tok(Token::Kind::Comma, ",")); break;
            case ';': out.push_back(tok(Token::Kind::Semicolon, ";")); break;
            case '.': out.push_back(tok(Token::Kind::Dot, ".")); break;
            case ':': out.push_back(tok(Token::Kind::Colon, ":")); break;
            case '+': out.push_back(tok(Token::Kind::Plus, "+")); break;
            case '-': out.push_back(tok(Token::Kind::Minus, "-")); break;
            case '*': out.push_back(tok(Token::Kind::Star, "*")); break;
            case '!': { bool eq = match('='); out.push_back(tok(eq ? Token::Kind::BangEqual : Token::Kind::Bang, eq ? "!=" : "!")); break; }
            case '=': { bool eq = match('='); out.push_back(tok(eq ? Token::Kind::EqualEqual : Token::Kind::Equal, eq ? "==" : "=")); break; }
            case '<': { bool eq = match('='); out.push_back(tok(eq ? Token::Kind::LessEqual : Token::Kind::Less, eq ? "<=" : "<")); break; }
            case '>': { bool eq = match('='); out.push_back(tok(eq ? Token::Kind::GreaterEqual : Token::Kind::Greater, eq ? ">=" : ">")); break; }
            case '"': out.push_back(stringToken()); break;
            default:
                if (std::isdigit(static_cast<unsigned char>(c)) || (c == '.' && std::isdigit(static_cast<unsigned char>(peek())))) out.push_back(number(c));
                else if (std::isalpha(static_cast<unsigned char>(c)) || c == '_') out.push_back(identifier(c));
                else error("unexpected character '" + std::string(1, c) + "'");
            }
        }
        out.push_back({Token::Kind::End, "", line_, col_});
        return out;
    }

private:
    std::string src_;
    size_t pos_ = 0;
    int line_ = 1, col_ = 1;
    bool atEnd() const { return pos_ >= src_.size(); }
    char peek() const { return atEnd() ? '\0' : src_[pos_]; }
    char peek2() const { return pos_ + 1 >= src_.size() ? '\0' : src_[pos_ + 1]; }
    char advance() { char c = src_[pos_++]; ++col_; return c; }
    bool match(char expected) { if (peek() != expected) return false; advance(); return true; }
    Token tok(Token::Kind k, std::string text) const { return {k, std::move(text), line_, col_}; }
    void error(const std::string& msg) const { throw std::runtime_error("line " + std::to_string(line_) + ": " + msg); }

    void blockComment() {
        while (!atEnd()) {
            if (peek() == '*' && peek2() == '/') { advance(); advance(); return; }
            char c = advance(); if (c == '\n') { ++line_; col_ = 1; }
        }
        error("unterminated block comment");
    }

    Token stringToken() {
        std::string out; int start = col_;
        while (!atEnd() && peek() != '"') {
            char c = advance();
            if (c == '\n') { ++line_; col_ = 1; }
            if (c == '\\' && !atEnd()) {
                char e = advance();
                switch (e) { case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break; case '"': out += '"'; break; case '\\': out += '\\'; break; default: out += e; break; }
            } else out += c;
        }
        if (atEnd()) error("unterminated string");
        advance();
        return {Token::Kind::String, out, line_, start};
    }

    Token number(char first) {
        std::string s(1, first);
        while (std::isdigit(static_cast<unsigned char>(peek())) || peek() == '.') s += advance();
        return tok(Token::Kind::Number, s);
    }

    Token identifier(char first) {
        std::string s(1, first);
        while (std::isalnum(static_cast<unsigned char>(peek())) || peek() == '_') s += advance();
        static const char* kws[] = {"fn","let","if","else","while","return","true","false","nil","import"};
        for (const char* k : kws) if (s == k) return tok(Token::Kind::Keyword, s);
        return tok(Token::Kind::Identifier, s);
    }
};

struct ReturnSignal { Value value; };

static std::string readFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open '" + path + "'");
    std::ostringstream ss; ss << f.rdbuf(); return ss.str();
}

static std::string lowerCopy(std::string s) { std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); }); return s; }
static std::string upperCopy(std::string s) { std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(std::toupper(c)); }); return s; }
static double numberArg(const std::vector<Value>& args, size_t i, const std::string& name) { if (i >= args.size() || args[i].type != Value::Type::Number) throw std::runtime_error(name + " expects number argument " + std::to_string(i + 1)); return args[i].number; }
static std::string stringArg(const std::vector<Value>& args, size_t i, const std::string& name) { if (i >= args.size() || args[i].type != Value::Type::String) throw std::runtime_error(name + " expects string argument " + std::to_string(i + 1)); return args[i].str; }
static void expectArity(const std::vector<Value>& args, size_t n, const std::string& name) { if (args.size() != n) throw std::runtime_error(name + " expects " + std::to_string(n) + " argument(s)"); }

static std::mt19937& rng() { static std::mt19937 g(static_cast<unsigned>(std::chrono::high_resolution_clock::now().time_since_epoch().count())); return g; }

static Value callStdlib(const std::string& name, const std::vector<Value>& args) {
    if (name == "file.read") { expectArity(args,1,name); return Value::String(readFile(stringArg(args,0,name))); }
    if (name == "file.write") { expectArity(args,2,name); std::ofstream f(stringArg(args,0,name), std::ios::binary|std::ios::trunc); if(!f) throw std::runtime_error("file.write: cannot open file"); f << stringArg(args,1,name); return Value::Bool(f.good()); }
    if (name == "file.append") { expectArity(args,2,name); std::ofstream f(stringArg(args,0,name), std::ios::binary|std::ios::app); if(!f) throw std::runtime_error("file.append: cannot open file"); f << stringArg(args,1,name); return Value::Bool(f.good()); }
    if (name == "file.exists") { expectArity(args,1,name); std::error_code ec; return Value::Bool(std::filesystem::exists(stringArg(args,0,name),ec) && !ec); }
    if (name == "file.remove") { expectArity(args,1,name); std::error_code ec; return Value::Bool(std::filesystem::remove(stringArg(args,0,name),ec) && !ec); }

    if (name == "string.len") { expectArity(args,1,name); return Value::Number(static_cast<double>(stringArg(args,0,name).size())); }
    if (name == "string.upper") { expectArity(args,1,name); return Value::String(upperCopy(stringArg(args,0,name))); }
    if (name == "string.lower") { expectArity(args,1,name); return Value::String(lowerCopy(stringArg(args,0,name))); }
    if (name == "string.contains") { expectArity(args,2,name); return Value::Bool(stringArg(args,0,name).find(stringArg(args,1,name)) != std::string::npos); }
    if (name == "string.starts_with") { expectArity(args,2,name); auto a=stringArg(args,0,name), b=stringArg(args,1,name); return Value::Bool(a.rfind(b,0)==0); }
    if (name == "string.ends_with") { expectArity(args,2,name); auto a=stringArg(args,0,name), b=stringArg(args,1,name); return Value::Bool(a.size()>=b.size() && a.compare(a.size()-b.size(),b.size(),b)==0); }

    if (name == "math.abs") { expectArity(args,1,name); return Value::Number(std::fabs(numberArg(args,0,name))); }
    if (name == "math.sqrt") { expectArity(args,1,name); return Value::Number(std::sqrt(numberArg(args,0,name))); }
    if (name == "math.pow") { expectArity(args,2,name); return Value::Number(std::pow(numberArg(args,0,name), numberArg(args,1,name))); }
    if (name == "math.floor") { expectArity(args,1,name); return Value::Number(std::floor(numberArg(args,0,name))); }
    if (name == "math.ceil") { expectArity(args,1,name); return Value::Number(std::ceil(numberArg(args,0,name))); }
    if (name == "math.round") { expectArity(args,1,name); return Value::Number(std::round(numberArg(args,0,name))); }
    if (name == "math.min") { expectArity(args,2,name); return Value::Number(std::min(numberArg(args,0,name),numberArg(args,1,name))); }
    if (name == "math.max") { expectArity(args,2,name); return Value::Number(std::max(numberArg(args,0,name),numberArg(args,1,name))); }
    if (name == "math.random") { if(args.empty()||args.size()>2) throw std::runtime_error("math.random expects 0, 1 or 2 arguments"); if(args.empty()) return Value::Number(std::generate_canonical<double, 20>(rng())); double a=numberArg(args,0,name), b=args.size()==2?numberArg(args,1,name):a; std::uniform_real_distribution<double> d(args.size()==2?a:0.0,b); return Value::Number(d(rng())); }

    if (name == "system.cwd") { expectArity(args,0,name); return Value::String(std::filesystem::current_path().string()); }
    if (name == "system.env") { expectArity(args,1,name); const char* v = std::getenv(stringArg(args,0,name).c_str()); return v ? Value::String(v) : Value::Nil(); }
    if (name == "system.exec") { expectArity(args,1,name); return Value::Number(static_cast<double>(std::system(stringArg(args,0,name).c_str()))); }
    if (name == "process.sleep") { expectArity(args,1,name); std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(numberArg(args,0,name)))); return Value::Nil(); }
    if (name == "process.pid") {
#ifdef _WIN32
        expectArity(args,0,name); return Value::Number(static_cast<double>(GetCurrentProcessId()));
#else
        expectArity(args,0,name); return Value::Number(static_cast<double>(getpid()));
#endif
    }

    if (name == "array.push") { expectArity(args,2,name); if(args[0].type!=Value::Type::Array) throw std::runtime_error("array.push expects array"); args[0].array->push_back(args[1]); return Value::Number(static_cast<double>(args[0].array->size())); }
    if (name == "array.pop") { expectArity(args,1,name); if(args[0].type!=Value::Type::Array) throw std::runtime_error("array.pop expects array"); if(args[0].array->empty()) return Value::Nil(); Value v=args[0].array->back(); args[0].array->pop_back(); return v; }
    if (name == "array.join") { expectArity(args,2,name); if(args[0].type!=Value::Type::Array) throw std::runtime_error("array.join expects array"); std::string sep=stringArg(args,1,name), out; for(size_t i=0;i<args[0].array->size();++i){if(i)out+=sep;out+=toString((*args[0].array)[i]);} return Value::String(out); }
    if (name == "array.contains") { expectArity(args,2,name); if(args[0].type!=Value::Type::Array) throw std::runtime_error("array.contains expects array"); for(const auto& v:*args[0].array) if(equalsValue(v,args[1])) return Value::Bool(true); return Value::Bool(false); }

    if (name == "map.get") { expectArity(args,2,name); if(args[0].type!=Value::Type::Map) throw std::runtime_error("map.get expects map"); std::string k=stringArg(args,1,name); auto it=args[0].map->find(k); return it==args[0].map->end()?Value::Nil():it->second; }
    if (name == "map.set") { expectArity(args,3,name); if(args[0].type!=Value::Type::Map) throw std::runtime_error("map.set expects map"); (*args[0].map)[stringArg(args,1,name)] = args[2]; return args[2]; }
    if (name == "map.has") { expectArity(args,2,name); if(args[0].type!=Value::Type::Map) throw std::runtime_error("map.has expects map"); return Value::Bool(args[0].map->count(stringArg(args,1,name)) != 0); }
    if (name == "map.keys") { expectArity(args,1,name); if(args[0].type!=Value::Type::Map) throw std::runtime_error("map.keys expects map"); std::vector<Value> out; for(const auto& [k,v]:*args[0].map) { (void)v; out.push_back(Value::String(k)); } return Value::Array(std::move(out)); }

    throw std::runtime_error("unknown standard library function '" + name + "'");
}

class Parser {
public:
    using Function = std::pair<std::vector<std::string>, std::vector<Token>>;
    Parser(std::vector<Token> tokens, std::filesystem::path filePath, std::shared_ptr<std::unordered_set<std::string>> loaded = {})
        : t_(std::move(tokens)), filePath_(std::move(filePath)), loaded_(std::move(loaded)) {
        if (!loaded_) loaded_ = std::make_shared<std::unordered_set<std::string>>();
    }

    void run(bool executeMain = true) {
        while (!check(Token::Kind::End)) {
            if (matchKeyword("fn")) parseFunction();
            else if (matchKeyword("import")) parseImport();
            else executeStatement();
        }
        if (executeMain) {
            auto it = functions_.find("main");
            if (it != functions_.end()) callFunction("main", {});
        }
    }

    const std::unordered_map<std::string, Function>& functions() const { return functions_; }
    const std::unordered_map<std::string, Value>& globals() const { return globals_; }

private:
    std::vector<Token> t_;
    size_t i_ = 0;
    std::filesystem::path filePath_;
    std::shared_ptr<std::unordered_set<std::string>> loaded_;
    std::unordered_map<std::string, Value> globals_;
    std::unordered_map<std::string, Function> functions_;

    const Token& cur() const { return t_[i_]; }
    bool check(Token::Kind k) const { return cur().kind == k; }
    const Token& advance() { if (!check(Token::Kind::End)) ++i_; return t_[i_-1]; }
    bool match(Token::Kind k) { if (!check(k)) return false; advance(); return true; }
    bool matchKeyword(const std::string& k) { if (cur().kind != Token::Kind::Keyword || cur().text != k) return false; advance(); return true; }
    [[noreturn]] void fail(const std::string& msg) const { throw std::runtime_error(filePath_.string() + ":" + std::to_string(cur().line) + ": " + msg); }
    void expect(Token::Kind k, const std::string& msg) { if (!match(k)) fail(msg); }

    void parseFunction() {
        if (!check(Token::Kind::Identifier)) fail("expected function name");
        std::string name = advance().text;
        expect(Token::Kind::LParen,"expected '('");
        std::vector<std::string> params;
        if (!check(Token::Kind::RParen)) { do { if(!check(Token::Kind::Identifier)) fail("expected parameter name"); params.push_back(advance().text); } while(match(Token::Kind::Comma)); }
        expect(Token::Kind::RParen,"expected ')'");
        expect(Token::Kind::LBrace,"expected '{'");
        size_t start=i_; int depth=1;
        while(depth>0 && !check(Token::Kind::End)){ if(check(Token::Kind::LBrace)) ++depth; else if(check(Token::Kind::RBrace)) --depth; advance(); }
        if(depth!=0) fail("unterminated function body");
        size_t finish=i_-1;
        functions_[name]={params,std::vector<Token>(t_.begin()+static_cast<long>(start),t_.begin()+static_cast<long>(finish))};
    }

    void parseImport() {
        if (!check(Token::Kind::String)) fail("expected module path after import");
        std::filesystem::path requested = advance().text;
        if (requested.extension() != ".diggcode") requested += ".diggcode";
        std::filesystem::path resolved = requested.is_absolute() ? requested : (filePath_.parent_path() / requested);
        resolved = std::filesystem::absolute(resolved).lexically_normal();
        match(Token::Kind::Semicolon);
        std::string key = resolved.string();
        if (loaded_->count(key)) return;
        loaded_->insert(key);
        std::string source = readFile(resolved.string());
        Lexer lexer(source);
        Parser module(lexer.lex(), resolved, loaded_);
        module.run(false);
        for (const auto& [name, fn] : module.functions_) functions_[name] = fn;
        for (const auto& [name, value] : module.globals_) globals_[name] = value;
    }

    Value evalExpression() { return comparison(); }
    Value comparison() {
        Value left = addition();
        while (check(Token::Kind::EqualEqual)||check(Token::Kind::BangEqual)||check(Token::Kind::Less)||check(Token::Kind::LessEqual)||check(Token::Kind::Greater)||check(Token::Kind::GreaterEqual)) {
            auto op=advance().kind; Value right=addition();
            bool r=false;
            if(op==Token::Kind::EqualEqual) r=equalsValue(left,right); else if(op==Token::Kind::BangEqual) r=!equalsValue(left,right);
            else { double a=left.type==Value::Type::Number?left.number:0,b=right.type==Value::Type::Number?right.number:0; if(op==Token::Kind::Less)r=a<b;else if(op==Token::Kind::LessEqual)r=a<=b;else if(op==Token::Kind::Greater)r=a>b;else if(op==Token::Kind::GreaterEqual)r=a>=b; }
            left=Value::Bool(r);
        }
        return left;
    }
    Value addition() {
        Value left=multiplication();
        while(check(Token::Kind::Plus)||check(Token::Kind::Minus)){auto op=advance().kind;Value right=multiplication();if(op==Token::Kind::Plus&&(left.type==Value::Type::String||right.type==Value::Type::String))left=Value::String(toString(left)+toString(right));else{double a=left.type==Value::Type::Number?left.number:0,b=right.type==Value::Type::Number?right.number:0;left=Value::Number(op==Token::Kind::Plus?a+b:a-b);}}
        return left;
    }
    Value multiplication() {
        Value left=unary();
        while(check(Token::Kind::Star)||check(Token::Kind::Slash)){auto op=advance().kind;Value right=unary();double a=left.type==Value::Type::Number?left.number:0,b=right.type==Value::Type::Number?right.number:0;if(op==Token::Kind::Slash&&b==0)fail("division by zero");left=Value::Number(op==Token::Kind::Star?a*b:a/b);} return left;
    }
    Value unary(){if(match(Token::Kind::Minus)){Value v=unary();return Value::Number(-(v.type==Value::Type::Number?v.number:0));}if(match(Token::Kind::Bang))return Value::Bool(!truthy(unary()));return postfix();}

    Value postfix() {
        Value value = primaryAtom();
        while (true) {
            if (match(Token::Kind::LBracket)) {
                Value index = evalExpression(); expect(Token::Kind::RBracket,"expected ']'");
                if (value.type==Value::Type::Array) {
                    if(index.type!=Value::Type::Number) fail("array index must be a number");
                    int idx=static_cast<int>(index.number); if(idx<0||static_cast<size_t>(idx)>=value.array->size()) fail("array index out of range"); value=(*value.array)[static_cast<size_t>(idx)];
                } else if(value.type==Value::Type::Map) {
                    if(index.type!=Value::Type::String) fail("map index must be a string");
                    auto it=value.map->find(index.str);
                    value=it==value.map->end()?Value::Nil():it->second;
                } else fail("value is not indexable");
                continue;
            }
            if (match(Token::Kind::Dot)) {
                if (!check(Token::Kind::Identifier)) fail("expected identifier after '.'");
                std::string field=advance().text;
                if (value.type==Value::Type::Map) {
                    auto it=value.map->find(field); value=it==value.map->end()?Value::Nil():it->second;
                } else fail("dot access expects a map");
                continue;
            }
            break;
        }
        return value;
    }

    Value primaryAtom() {
        if(match(Token::Kind::Number)) return Value::Number(std::stod(t_[i_-1].text));
        if(match(Token::Kind::String)) return Value::String(t_[i_-1].text);
        if(matchKeyword("true")) return Value::Bool(true);
        if(matchKeyword("false")) return Value::Bool(false);
        if(matchKeyword("nil")) return Value::Nil();
        if(match(Token::Kind::LParen)){Value v=evalExpression();expect(Token::Kind::RParen,"expected ')'");return v;}
        if(match(Token::Kind::LBracket)){
            std::vector<Value> items; if(!check(Token::Kind::RBracket)){do{items.push_back(evalExpression());}while(match(Token::Kind::Comma));}expect(Token::Kind::RBracket,"expected ']'");
            Value v=Value::Array(std::move(items));
            // Function call support is handled in identifier branch; collection methods use stdlib directly.
            return v;
        }
        if(match(Token::Kind::LBrace)){
            std::map<std::string,Value> m;
            if(!check(Token::Kind::RBrace)){
                do {
                    if(!check(Token::Kind::String)) fail("map keys must be strings");
                    std::string key=advance().text; expect(Token::Kind::Colon,"expected ':' after map key"); m[key]=evalExpression();
                } while(match(Token::Kind::Comma));
            }
            expect(Token::Kind::RBrace,"expected '}'"); return Value::Map(std::move(m));
        }
        if(match(Token::Kind::Identifier)){
            std::string name=t_[i_-1].text;
            while(match(Token::Kind::Dot)){if(!check(Token::Kind::Identifier))fail("expected identifier after '.'");name+="."+advance().text;}
            if(match(Token::Kind::LParen)){
                std::vector<Value> args; if(!check(Token::Kind::RParen)){do{args.push_back(evalExpression());}while(match(Token::Kind::Comma));} expect(Token::Kind::RParen,"expected ')' after arguments");
                if(name=="print"||name=="println"){for(size_t n=0;n<args.size();++n){if(n)std::cout<<' ';std::cout<<toString(args[n]);}if(name=="println")std::cout<<'\n';return Value::Nil();}
                if(name=="len"){expectArity(args,1,name); if(args[0].type==Value::Type::Array)return Value::Number(args[0].array->size());if(args[0].type==Value::Type::Map)return Value::Number(args[0].map->size());return Value::Number(toString(args[0]).size());}
                if(name.find('.')!=std::string::npos)return callStdlib(name,args);
                return callFunction(name,args);
            }
            auto it=globals_.find(name);return it==globals_.end()?Value::Nil():it->second;
        }
        fail("expected expression");
    }

    static bool isAssignmentAhead(const std::vector<Token>& tokens, size_t start) {
        size_t p=start+1;
        if (p < tokens.size() && tokens[p].kind == Token::Kind::Equal) return true;
        if (p < tokens.size() && tokens[p].kind == Token::Kind::LBracket) {
            int depth=0; do { if(tokens[p].kind==Token::Kind::LBracket)++depth; else if(tokens[p].kind==Token::Kind::RBracket)--depth; ++p; } while(p<tokens.size()&&depth>0);
            return p<tokens.size()&&tokens[p].kind==Token::Kind::Equal;
        }
        return false;
    }

    void executeStatement(){
        if(matchKeyword("let")){if(!check(Token::Kind::Identifier))fail("expected variable name");std::string name=advance().text;expect(Token::Kind::Equal,"expected '=' after variable name");globals_[name]=evalExpression();match(Token::Kind::Semicolon);return;}
        if(matchKeyword("import")){parseImport();return;}
        if(matchKeyword("if")){expect(Token::Kind::LParen,"expected '('");Value c=evalExpression();expect(Token::Kind::RParen,"expected ')'");executeBlock(truthy(c));if(matchKeyword("else"))executeBlock(!truthy(c));return;}
        if(matchKeyword("while")){runWhile();return;}
        if(matchKeyword("return")){Value v=check(Token::Kind::RBrace)?Value::Nil():evalExpression();match(Token::Kind::Semicolon);throw ReturnSignal{v};}
        if(check(Token::Kind::Identifier) && isAssignmentAhead(t_,i_)){assignStatement();return;}
        (void)evalExpression();match(Token::Kind::Semicolon);
    }

    void assignStatement(){
        std::string name=advance().text;
        if(match(Token::Kind::Equal)){globals_[name]=evalExpression();match(Token::Kind::Semicolon);return;}
        expect(Token::Kind::LBracket,"expected '['"); Value index=evalExpression(); expect(Token::Kind::RBracket,"expected ']'"); expect(Token::Kind::Equal,"expected '=' after index"); Value rhs=evalExpression();
        auto it=globals_.find(name); if(it==globals_.end()) fail("unknown variable '"+name+"'");
        if(it->second.type==Value::Type::Array){if(index.type!=Value::Type::Number)fail("array index must be a number");int idx=static_cast<int>(index.number);if(idx<0||static_cast<size_t>(idx)>=it->second.array->size())fail("array index out of range");(*it->second.array)[static_cast<size_t>(idx)]=rhs;}
        else if(it->second.type==Value::Type::Map){if(index.type!=Value::Type::String)fail("map index must be a string");(*it->second.map)[index.str]=rhs;}
        else fail("variable is not indexable");
        match(Token::Kind::Semicolon);
    }

    void runWhile(){
        expect(Token::Kind::LParen,"expected '('");size_t condStart=i_;(void)evalExpression();size_t condEnd=i_;expect(Token::Kind::RParen,"expected ')'");if(!check(Token::Kind::LBrace))fail("expected '{'");advance();size_t bodyStart=i_;int depth=1;while(depth>0&&!check(Token::Kind::End)){if(check(Token::Kind::LBrace))++depth;else if(check(Token::Kind::RBrace))--depth;advance();}if(depth!=0)fail("unterminated while body");size_t bodyEnd=i_-1;size_t after=i_;auto original=t_;std::vector<Token> cond(original.begin()+static_cast<long>(condStart),original.begin()+static_cast<long>(condEnd));std::vector<Token> body(original.begin()+static_cast<long>(bodyStart),original.begin()+static_cast<long>(bodyEnd));
        for(int guard=0;guard<100000;++guard){t_=cond;t_.push_back({Token::Kind::End,"",1,1});i_=0;Value c=evalExpression();if(!truthy(c))break;t_=body;t_.push_back({Token::Kind::End,"",1,1});i_=0;while(!check(Token::Kind::End))executeStatement();}
        t_=std::move(original);i_=after;
    }

    void executeBlock(bool shouldRun){expect(Token::Kind::LBrace,"expected '{'");size_t start=i_;int depth=1;while(depth&&!check(Token::Kind::End)){if(check(Token::Kind::LBrace))++depth;else if(check(Token::Kind::RBrace))--depth;advance();}if(depth!=0)fail("unterminated block");size_t end=i_-1;if(!shouldRun)return;auto saved=std::move(t_);auto savedI=i_;t_=std::vector<Token>(saved.begin()+static_cast<long>(start),saved.begin()+static_cast<long>(end));i_=0;while(!check(Token::Kind::End))executeStatement();t_=std::move(saved);i_=savedI;}

    Value callFunction(const std::string& name,const std::vector<Value>& args){auto it=functions_.find(name);if(it==functions_.end())fail("unknown function '"+name+"'");auto saved=globals_;for(size_t n=0;n<it->second.first.size();++n)globals_[it->second.first[n]]=n<args.size()?args[n]:Value::Nil();auto savedTokens=std::move(t_);auto savedI=i_;t_=it->second.second;t_.push_back({Token::Kind::End,"",1,1});i_=0;Value result=Value::Nil();try{while(!check(Token::Kind::End))executeStatement();}catch(const ReturnSignal& r){result=r.value;}t_=std::move(savedTokens);i_=savedI;globals_=std::move(saved);return result;}
};

} // namespace digg

int main(int argc,char** argv){
    if(argc<2){std::cerr<<"Usage: digg-runtime <file.diggcode>\n";return 2;}
    try{
        std::filesystem::path path=std::filesystem::absolute(argv[1]).lexically_normal();
        if(path.extension()!=".diggcode") throw std::runtime_error("DIGG runtime expects a .diggcode file");
        auto source=digg::readFile(path.string());digg::Lexer lexer(source);auto loaded=std::make_shared<std::unordered_set<std::string>>();loaded->insert(path.string());digg::Parser parser(lexer.lex(),path,loaded);parser.run(true);return 0;
    }catch(const std::exception& e){std::cerr<<"DIGG error: "<<e.what()<<'\n';return 1;}
}
