#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include <windows.h>
#include <commctrl.h>
#include <richedit.h>
#include <shellapi.h>
#include <shlobj.h>
#include <string>
#include <thread>
#include <mutex>
#include <atomic>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <memory>
#include <chrono>
#include <iterator>
#include <utility>
#include <cwctype>
#include <cstring>

#pragma comment(lib, "Comctl32.lib")
#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "Ole32.lib")

namespace fs = std::filesystem;

static constexpr wchar_t APP_CLASS[] = L"DEIIGMainWindow";
static constexpr wchar_t APP_VERSION[] = L"DEIIG 0.8";

enum : int {
    IDC_EXPLORER = 1001,
    IDC_EDITOR = 1002,
    IDC_TERMINAL = 1003,
    IDC_TERM_INPUT = 1004,
    IDC_STATUS = 1005,
    IDC_OPEN_PROJECT = 1006,
    IDC_SAVE = 1007,
    IDC_RUN_EXE = 1008,
    IDC_OPEN_BROWSER = 1009,
    IDC_NEW = 1010,
    IDC_TITLE = 1011,
    IDC_BUILD = 1012,
    IDC_RUN = 1013,
    IDC_OPEN_FILE = 1014,
    IDC_NEW_FOLDER = 1015,
    IDC_REFRESH = 1016,
    IDC_REVEAL = 1017,
    IDC_FOCUS_TERMINAL = 1018,
    IDC_PREVIEW = 1019,
    IDC_TASKS = 1020,
    IDC_AI = 1021,
    IDC_PROBLEMS = 1022,
    IDC_SPLIT = 1023,
    IDC_INSPECT = 1024,
    IDC_LIB = 1025,
    IDC_GOOGLE = 1026,
    IDC_BING = 1027,
};

enum : UINT {
    WM_APPEND_TERM = WM_APP + 1,
    WM_HIGHLIGHT_EDITOR = WM_APP + 2,
};

struct AppState {
    HWND hwnd{};
    HWND title{};
    HWND explorer{};
    HWND editor{};
    HWND editor2{};
    HWND terminal{};
    HWND termInput{};
    HWND status{};
    HFONT uiFont{};
    HFONT monoFont{};

    fs::path projectDir{};
    fs::path currentFile{};
    std::vector<fs::path> explorerItems{};
    bool editorDirty = false;
    bool suppressEditorDirty = false;
    bool splitView = false;
    bool diggCodeMode = false;
    bool highlighting = false;

    HANDLE cmdIn{};
    PROCESS_INFORMATION cmdPi{};
    std::thread cmdReader;
    std::atomic<bool> cmdRunning{false};
    std::mutex cmdWriteMutex;

    PROCESS_INFORMATION runPi{};

    std::vector<std::wstring> commandHistory{};
    int historyPos = -1;
    std::vector<fs::path> recentProjects{};
};

static AppState g;
static WNDPROC g_oldTermProc{};
static WNDPROC g_oldEditorProc{};
static void RefreshExplorer();
static LRESULT CALLBACK TermInputProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l);
static LRESULT CALLBACK EditorProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l);
static LRESULT CALLBACK PromptWndProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l);
static LRESULT CALLBACK PreviewWndProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l);
static bool IsDiggCodeMode();
static void HighlightDiggSyntax(HWND hwnd);
static void HighlightDiggBracketMatch(HWND hwnd);

static std::wstring Widen(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    if (n <= 0) return {};
    std::wstring out(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), out.data(), n);
    return out;
}

static std::string Narrow(const std::wstring& s) {
    if (s.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return {};
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), out.data(), n, nullptr, nullptr);
    return out;
}

static std::wstring GetText(HWND hwnd) {
    int len = GetWindowTextLengthW(hwnd);
    if (len <= 0) return {};
    std::wstring out(static_cast<size_t>(len) + 1, L'\0');
    GetWindowTextW(hwnd, out.data(), len + 1);
    out.resize(static_cast<size_t>(len));
    return out;
}

static void SetWindowTextAndClearDirty(HWND hwnd, const std::wstring& text) {
    g.suppressEditorDirty = true;
    SetWindowTextW(hwnd, text.c_str());
    g.suppressEditorDirty = false;
    g.editorDirty = false;
}

static void Status(const std::wstring& text) {
    if (g.status) SetWindowTextW(g.status, text.c_str());
}

static void UpdateTitle() {
    std::wstring name = g.currentFile.empty() ? L"Untitled" : g.currentFile.filename().wstring();
    std::wstring title = APP_VERSION;
    if (!g.projectDir.empty()) title += L" — " + g.projectDir.filename().wstring();
    title += L" — " + name;
    if (g.editorDirty) title += L" *";
    if (g.title) SetWindowTextW(g.title, title.c_str());
}

static void AppendTerminal(const std::wstring& text) {
    if (!g.terminal) return;
    int len = GetWindowTextLengthW(g.terminal);
    SendMessageW(g.terminal, EM_SETSEL, len, len);
    SendMessageW(g.terminal, EM_REPLACESEL, FALSE, (LPARAM)text.c_str());
    SendMessageW(g.terminal, EM_SCROLLCARET, 0, 0);
}

static bool ReadFileUtf8(const fs::path& path, std::wstring& out) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::string bytes((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    if (bytes.size() >= 3 && (unsigned char)bytes[0] == 0xEF && (unsigned char)bytes[1] == 0xBB && (unsigned char)bytes[2] == 0xBF)
        bytes.erase(0, 3);
    out = Widen(bytes);
    return true;
}

static bool WriteFileUtf8(const fs::path& path, const std::wstring& text) {
    std::error_code ec;
    if (!path.parent_path().empty()) fs::create_directories(path.parent_path(), ec);
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    const std::string bytes = Narrow(text);
    f.write(bytes.data(), (std::streamsize)bytes.size());
    return f.good();
}

static fs::path AppDataDir() {
    wchar_t buf[MAX_PATH * 4]{};
    DWORD n = GetEnvironmentVariableW(L"APPDATA", buf, (DWORD)std::size(buf));
    if (n == 0 || n >= std::size(buf)) return fs::current_path() / L".deiig";
    return fs::path(buf) / L"DEIIG";
}

static fs::path RecentFilePath() {
    return AppDataDir() / L"recent-projects.txt";
}

static void SaveRecentProjects() {
    std::error_code ec;
    fs::create_directories(AppDataDir(), ec);
    std::ofstream f(RecentFilePath(), std::ios::binary | std::ios::trunc);
    if (!f) return;
    const size_t limit = std::min<size_t>(g.recentProjects.size(), 12);
    for (size_t i = 0; i < limit; ++i) {
        f << Narrow(g.recentProjects[i].wstring()) << '\n';
    }
}

static void LoadRecentProjects() {
    g.recentProjects.clear();
    std::ifstream f(RecentFilePath(), std::ios::binary);
    if (!f) return;
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        fs::path p = Widen(line);
        std::error_code ec;
        if (fs::is_directory(p, ec)) g.recentProjects.push_back(fs::absolute(p, ec));
        if (g.recentProjects.size() >= 12) break;
    }
}

static void TouchRecentProject(const fs::path& dir) {
    std::vector<fs::path> next;
    for (const auto& p : g.recentProjects) {
        if (fs::weakly_canonical(p) != fs::weakly_canonical(dir)) next.push_back(p);
    }
    next.insert(next.begin(), fs::absolute(dir));
    if (next.size() > 12) next.resize(12);
    g.recentProjects = std::move(next);
    SaveRecentProjects();
}

static bool ConfirmDiscardChanges() {
    if (!g.editorDirty) return true;
    int r = MessageBoxW(g.hwnd, L"The current file has unsaved changes. Discard them?", L"DEIIG", MB_YESNO | MB_ICONWARNING);
    return r == IDYES;
}

static fs::path ChooseFolder() {
    BROWSEINFOW bi{};
    bi.hwndOwner = g.hwnd;
    bi.lpszTitle = L"DEIIG project folder";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&bi);
    if (!pidl) return {};
    wchar_t path[MAX_PATH]{};
    SHGetPathFromIDListW(pidl, path);
    CoTaskMemFree(pidl);
    return path;
}

static fs::path ChooseFile(const wchar_t* filter, bool mustExist = true) {
    OPENFILENAMEW ofn{};
    wchar_t file[MAX_PATH * 4]{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g.hwnd;
    ofn.lpstrFilter = filter;
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH * 4;
    ofn.Flags = (mustExist ? OFN_FILEMUSTEXIST : 0) | OFN_PATHMUSTEXIST;
    if (!GetOpenFileNameW(&ofn)) return {};
    return file;
}

static fs::path ChooseSaveFile(const wchar_t* filter, const fs::path& suggested = {}) {
    OPENFILENAMEW ofn{};
    wchar_t file[MAX_PATH * 4]{};
    if (!suggested.empty()) wcsncpy_s(file, std::size(file), suggested.wstring().c_str(), _TRUNCATE);
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g.hwnd;
    ofn.lpstrFilter = filter;
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH * 4;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    if (!GetSaveFileNameW(&ofn)) return {};
    return file;
}


struct PromptState {
    HWND hwnd{};
    HWND edit{};
    std::wstring value;
    std::wstring prompt;
    std::wstring title;
    bool done = false;
    bool accepted = false;
};

static LRESULT CALLBACK PromptWndProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    auto* ps = reinterpret_cast<PromptState*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (msg == WM_NCCREATE) {
        auto* cs = reinterpret_cast<CREATESTRUCTW*>(l);
        ps = reinterpret_cast<PromptState*>(cs->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, (LONG_PTR)ps);
        ps->hwnd = hwnd;
    }
    if (!ps) return DefWindowProcW(hwnd, msg, w, l);
    switch (msg) {
    case WM_CREATE: {
        HFONT font = g.uiFont ? g.uiFont : (HFONT)GetStockObject(DEFAULT_GUI_FONT);
        CreateWindowExW(0, L"STATIC", ps->prompt.c_str(), WS_CHILD | WS_VISIBLE,
            16, 14, 460, 38, hwnd, nullptr, GetModuleHandleW(nullptr), nullptr);
        ps->edit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", ps->value.c_str(),
            WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 16, 55, 460, 28,
            hwnd, (HMENU)1, GetModuleHandleW(nullptr), nullptr);
        CreateWindowExW(0, L"BUTTON", L"OK", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
            300, 96, 80, 28, hwnd, (HMENU)IDOK, GetModuleHandleW(nullptr), nullptr);
        CreateWindowExW(0, L"BUTTON", L"Cancel", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            395, 96, 80, 28, hwnd, (HMENU)IDCANCEL, GetModuleHandleW(nullptr), nullptr);
        SendMessageW(ps->edit, WM_SETFONT, (WPARAM)font, TRUE);
        SetFocus(ps->edit);
        SendMessageW(ps->edit, EM_SETSEL, 0, -1);
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(w) == IDOK) {
            ps->value = GetText(ps->edit);
            ps->accepted = true;
            ps->done = true;
            DestroyWindow(hwnd);
            return 0;
        }
        if (LOWORD(w) == IDCANCEL) {
            ps->accepted = false;
            ps->done = true;
            DestroyWindow(hwnd);
            return 0;
        }
        break;
    case WM_CLOSE:
        ps->accepted = false;
        ps->done = true;
        DestroyWindow(hwnd);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, w, l);
}

static bool PromptText(const std::wstring& title, const std::wstring& prompt, std::wstring& value) {
    static ATOM atom = 0;
    if (!atom) {
        WNDCLASSW wc{};
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.lpfnWndProc = PromptWndProc;
        wc.lpszClassName = L"DEIIGPromptWindow";
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        atom = RegisterClassW(&wc);
    }
    PromptState ps;
    ps.value = value;
    ps.prompt = prompt;
    ps.title = title;
    HWND dlg = CreateWindowExW(WS_EX_DLGMODALFRAME | WS_EX_TOPMOST, L"DEIIGPromptWindow", title.c_str(),
        WS_POPUP | WS_CAPTION | WS_SYSMENU, CW_USEDEFAULT, CW_USEDEFAULT, 500, 145,
        g.hwnd, nullptr, GetModuleHandleW(nullptr), &ps);
    if (!dlg) return false;
    RECT owner{}; GetWindowRect(g.hwnd, &owner);
    RECT wr{}; GetWindowRect(dlg, &wr);
    const int w = wr.right - wr.left, h = wr.bottom - wr.top;
    SetWindowPos(dlg, HWND_TOP, (owner.left + owner.right - w) / 2, (owner.top + owner.bottom - h) / 2,
        w, h, SWP_SHOWWINDOW);
    EnableWindow(g.hwnd, FALSE);
    MSG msg{};
    while (!ps.done && GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (!IsDialogMessageW(dlg, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    EnableWindow(g.hwnd, TRUE);
    SetForegroundWindow(g.hwnd);
    if (ps.accepted) value = ps.value;
    return ps.accepted;
}

static std::wstring GetTerminalText() {
    return GetText(g.terminal);
}

static void CopyTextToClipboard(const std::wstring& text) {
    if (!OpenClipboard(g.hwnd)) return;
    EmptyClipboard();
    const size_t bytes = (text.size() + 1) * sizeof(wchar_t);
    HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (h) {
        void* p = GlobalLock(h);
        if (p) {
            memcpy(p, text.c_str(), bytes);
            GlobalUnlock(h);
            SetClipboardData(CF_UNICODETEXT, h);
        } else GlobalFree(h);
    }
    CloseClipboard();
}

static std::wstring UrlEncodeUtf8(const std::wstring& text) {
    const std::string utf8 = Narrow(text);
    std::ostringstream out;
    const char* hex = "0123456789ABCDEF";
    for (unsigned char c : utf8) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') out << c;
        else if (c == ' ') out << '+';
        else out << '%' << hex[c >> 4] << hex[c & 15];
    }
    return Widen(out.str());
}

static void WebSearch(const wchar_t* engine) {
    std::wstring q;
    if (!PromptText(std::wstring(engine) + L" Search", L"Search the web:", q) || q.empty()) return;
    const std::wstring base = std::wstring(engine) == L"Google"
        ? L"https://www.google.com/search?q="
        : L"https://www.bing.com/search?q=";
    const std::wstring url = base + UrlEncodeUtf8(q);
    ShellExecuteW(g.hwnd, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    Status(std::wstring(engine) + L" search: " + q);
}

static void InstallLibrary() {
    std::wstring cmd;
    if (!PromptText(L"DEIIG Library Installer", L"Enter a package-manager command. Examples: vcpkg install fmt  |  conan install .  |  pip install requests", cmd) || cmd.empty()) return;
    SendCmd(cmd);
    AppendTerminal(L"\r\n[DEIIG] Library command: " + cmd + L"\r\n");
    Status(L"Library command sent to terminal.");
}

static void OpenPreviewWindow(const std::wstring& text, const std::wstring& title) {
    static ATOM atom = 0;
    if (!atom) {
        WNDCLASSW wc{};
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.lpfnWndProc = PreviewWndProc;
        wc.lpszClassName = L"DEIIGPreviewWindow";
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        atom = RegisterClassW(&wc);
    }
    auto* payload = new std::wstring(text);
    HWND w = CreateWindowExW(WS_EX_APPWINDOW, L"DEIIGPreviewWindow", title.c_str(),
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 900, 650,
        g.hwnd, nullptr, GetModuleHandleW(nullptr), payload);
    if (w) ShowWindow(w, SW_SHOW);
    else delete payload;
}

static LRESULT CALLBACK PreviewWndProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    static HWND edit = nullptr;
    if (msg == WM_CREATE) {
        auto* cs = reinterpret_cast<CREATESTRUCTW*>(l);
        auto* payload = reinterpret_cast<std::wstring*>(cs->lpCreateParams);
        LoadLibraryW(L"Msftedit.dll");
        edit = CreateWindowExW(WS_EX_CLIENTEDGE, MSFTEDIT_CLASS, payload ? payload->c_str() : L"",
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
            0, 0, 100, 100, hwnd, nullptr, GetModuleHandleW(nullptr), nullptr);
        if (g.monoFont) SendMessageW(edit, WM_SETFONT, (WPARAM)g.monoFont, TRUE);
        delete payload;
        return 0;
    }
    if (msg == WM_SIZE && edit) SetWindowPos(edit, nullptr, 0, 0, LOWORD(l), HIWORD(l), SWP_NOZORDER);
    if (msg == WM_NCDESTROY) edit = nullptr;
    return DefWindowProcW(hwnd, msg, w, l);
}

static void PreviewCurrent() {
    if (g.currentFile.empty()) { MessageBoxW(g.hwnd, L"Open a file first.", L"DEIIG Preview", MB_ICONINFORMATION); return; }
    const auto ext = g.currentFile.extension().wstring();
    if (ext == L".png" || ext == L".jpg" || ext == L".jpeg" || ext == L".gif" || ext == L".bmp" || ext == L".webp") {
        ShellExecuteW(g.hwnd, L"open", g.currentFile.wstring().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        return;
    }
    std::wstring text;
    if (!ReadFileUtf8(g.currentFile, text)) { MessageBoxW(g.hwnd, L"Preview is not available for this file.", L"DEIIG Preview", MB_ICONINFORMATION); return; }
    OpenPreviewWindow(text, L"Preview — " + g.currentFile.filename().wstring());
}

static void RunTask() {
    if (g.projectDir.empty()) { MessageBoxW(g.hwnd, L"Open a project first.", L"DEIIG Tasks", MB_ICONINFORMATION); return; }
    std::wstring name = L"build";
    if (!PromptText(L"DEIIG Tasks", L"Task name (built-in: build, test, run; custom: NAME=command in DEIIG.tasks):", name) || name.empty()) return;
    std::wstring command;
    if (name == L"build") command = L"cmake -S . -B build && cmake --build build --config Release";
    else if (name == L"test") command = L"ctest --test-dir build --output-on-failure";
    else if (name == L"run") command = L"echo Use F5 or Run after building";
    else {
        std::ifstream f(g.projectDir / L"DEIIG.tasks", std::ios::binary);
        std::string line;
        const std::string wanted = Narrow(name) + "=";
        while (std::getline(f, line)) if (line.rfind(wanted, 0) == 0) { command = Widen(line.substr(wanted.size())); break; }
    }
    if (command.empty()) { MessageBoxW(g.hwnd, L"Task not found. Create DEIIG.tasks with lines like: lint=clang-tidy src/*.cpp", L"DEIIG Tasks", MB_ICONINFORMATION); return; }
    AppendTerminal(L"\r\n[TASK " + name + L"] " + command + L"\r\n");
    SendCmd(command);
}

static void ShowProblems() {
    const std::wstring terminal = GetTerminalText();
    std::wstringstream ss(terminal);
    std::wstring line, hits;
    int count = 0;
    while (std::getline(ss, line)) {
        std::wstring low = line;
        std::transform(low.begin(), low.end(), low.begin(), towlower);
        if (low.find(L"error") != std::wstring::npos || low.find(L"warning") != std::wstring::npos) {
            hits += line + L"\r\n";
            if (++count >= 80) break;
        }
    }
    if (hits.empty()) hits = L"No error/warning lines were found in the current terminal output.\r\n";
    OpenPreviewWindow(hits, L"DEIIG Problems");
}

static std::wstring BuildAIContext() {
    std::wstring out = L"# DEIIG AI Workspace\r\n\r\n";
    out += L"## Current File\r\n" + (g.currentFile.empty() ? L"(unsaved)" : g.currentFile.wstring()) + L"\r\n\r\n";
    out += L"## Source\r\n```\r\n" + GetText(g.editor).substr(0, 30000) + L"\r\n```\r\n\r\n";
    if (g.splitView && g.editor2) out += L"## Split View\r\n```\r\n" + GetText(g.editor2).substr(0, 30000) + L"\r\n```\r\n\r\n";
    out += L"## Project\r\n" + (g.projectDir.empty() ? L"(none)" : g.projectDir.wstring()) + L"\r\n";
    if (!g.projectDir.empty()) {
        size_t shown = 0;
        for (const auto& item : g.explorerItems) if (!item.empty() && shown++ < 100) out += L"- " + fs::relative(item, g.projectDir).wstring() + L"\r\n";
    }
    out += L"\r\n## Terminal\r\n```text\r\n" + GetTerminalText().substr(0, 20000) + L"\r\n```\r\n";
    return out;
}

static void AIWorkspace() {
    const std::wstring context = BuildAIContext();
    CopyTextToClipboard(context);
    ShellExecuteW(g.hwnd, L"open", L"https://chatgpt.com/", nullptr, nullptr, SW_SHOWNORMAL);
    Status(L"AI context copied to clipboard and ChatGPT opened.");
    MessageBoxW(g.hwnd, L"DEIIG copied the current file, project tree, and terminal context to the clipboard. Paste it into your AI chat.", L"DEIIG AI Workspace", MB_ICONINFORMATION);
}

static void ToggleSplitView() {
    g.splitView = !g.splitView;
    if (g.splitView && !g.editor2) {
        LoadLibraryW(L"Msftedit.dll");
        g.editor2 = CreateWindowExW(WS_EX_CLIENTEDGE, MSFTEDIT_CLASS, nullptr,
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_READONLY,
            0, 0, 300, 300, g.hwnd, nullptr, GetModuleHandleW(nullptr), nullptr);
        ApplyFont(g.editor2, g.monoFont);
        SetWindowTextW(g.editor2, GetText(g.editor).c_str());
    }
    if (g.editor2) ShowWindow(g.editor2, g.splitView ? SW_SHOW : SW_HIDE);
    Layout(g.hwnd);
    Status(g.splitView ? L"Split view enabled." : L"Split view disabled.");
}

static void InspectExe() {
    fs::path exe = ChooseFile(L"Executable\0*.exe\0All files\0*.*\0");
    if (exe.empty()) return;
    WIN32_FILE_ATTRIBUTE_DATA fad{};
    LARGE_INTEGER size{};
    GetFileAttributesExW(exe.wstring().c_str(), GetFileExInfoStandard, &fad);
    HANDLE h = CreateFileW(exe.wstring().c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h != INVALID_HANDLE_VALUE) { GetFileSizeEx(h, &size); CloseHandle(h); }
    DWORD type = 0; GetBinaryTypeW(exe.wstring().c_str(), &type);
    const wchar_t* arch = type == SCS_64BIT_BINARY ? L"x64 or ARM64 native" : type == SCS_32BIT_BINARY ? L"x86 / 32-bit" : L"unknown";
    std::wstringstream ss;
    ss << L"EXE Inspector\r\n\r\nPath: " << exe.wstring() << L"\r\nSize: " << size.QuadPart << L" bytes\r\nArchitecture: " << arch << L"\r\n";
    OpenPreviewWindow(ss.str(), L"EXE Inspector — " + exe.filename().wstring());
}

static void SetWorkingDirectoryForTerminal() {
    if (!g.cmdIn || g.projectDir.empty()) return;
    std::wstring command = L"cd /d \"" + g.projectDir.wstring() + L"\"";
    int n = WideCharToMultiByte(CP_OEMCP, 0, command.data(), (int)command.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return;
    std::string bytes(n, '\0');
    WideCharToMultiByte(CP_OEMCP, 0, command.data(), (int)command.size(), bytes.data(), n, nullptr, nullptr);
    bytes += "\r\n";
    DWORD written = 0;
    std::lock_guard<std::mutex> lock(g.cmdWriteMutex);
    WriteFile(g.cmdIn, bytes.data(), (DWORD)bytes.size(), &written, nullptr);
}

static bool IsDiggCodeMode() {
    return g.diggCodeMode || (!g.currentFile.empty() && g.currentFile.extension() == L".diggcode");
}

static void LoadEditor(const fs::path& path) {
    if (!ConfirmDiscardChanges()) return;
    std::wstring text;
    if (!ReadFileUtf8(path, text)) {
        MessageBoxW(g.hwnd, L"Unable to read the file.", L"DEIIG", MB_ICONERROR);
        return;
    }
    SetWindowTextAndClearDirty(g.editor, text);
    g.currentFile = path;
    g.diggCodeMode = (path.extension() == L".diggcode");
    if (g.diggCodeMode) HighlightDiggSyntax(g.editor);
    UpdateTitle();
    Status(L"Opened: " + path.wstring());
}

static bool SaveEditorTo(const fs::path& path) {
    const std::wstring text = GetText(g.editor);
    if (!WriteFileUtf8(path, text)) return false;
    g.currentFile = path;
    g.diggCodeMode = (path.extension() == L".diggcode");
    g.editorDirty = false;
    if (g.editor2) SetWindowTextW(g.editor2, text.c_str());
    if (g.diggCodeMode) HighlightDiggSyntax(g.editor);
    UpdateTitle();
    Status(L"Saved: " + path.wstring());
    return true;
}

static void SaveEditor() {
    if (g.currentFile.empty()) {
        fs::path suggested = g.projectDir.empty() ? fs::path(L"main.diggcode") : (g.projectDir / L"main.diggcode");
        fs::path target = ChooseSaveFile(L"DEIIG Code\0*.diggcode\0C/C++ files\0*.cpp;*.h;*.hpp;*.c\0Text files\0*.txt;*.md\0All files\0*.*\0", suggested);
        if (target.empty()) return;
        if (!SaveEditorTo(target)) MessageBoxW(g.hwnd, L"Save failed.", L"DEIIG", MB_ICONERROR);
        RefreshExplorer();
        return;
    }
    if (!SaveEditorTo(g.currentFile)) MessageBoxW(g.hwnd, L"Save failed.", L"DEIIG", MB_ICONERROR);
    RefreshExplorer();
}

static void RefreshExplorer() {
    g.explorerItems.clear();
    SendMessageW(g.explorer, LB_RESETCONTENT, 0, 0);
    if (g.projectDir.empty()) {
        SendMessageW(g.explorer, LB_ADDSTRING, 0, (LPARAM)L"Open a project folder...");
        return;
    }
    std::wstring header = L"[PROJECT] " + g.projectDir.filename().wstring();
    SendMessageW(g.explorer, LB_ADDSTRING, 0, (LPARAM)header.c_str());
    g.explorerItems.emplace_back();
    try {
        std::vector<fs::directory_entry> items;
        fs::recursive_directory_iterator it(g.projectDir, fs::directory_options::skip_permission_denied), end;
        for (; it != end; ++it) {
            const auto& e = *it;
            const auto name = e.path().filename().wstring();
            if (e.is_directory() && (name == L"build" || name == L".git" || name == L".vs" || name == L".idea")) {
                it.disable_recursion_pending();
                continue;
            }
            if (e.is_regular_file()) {
                auto ext = e.path().extension().wstring();
                if (ext == L".obj" || ext == L".pdb" || ext == L".exe" || ext == L".dll" || ext == L".ilk") continue;
            }
            items.push_back(e);
        }
        std::sort(items.begin(), items.end(), [](const auto& a, const auto& b) {
            if (a.is_directory() != b.is_directory()) return a.is_directory() > b.is_directory();
            return a.path().wstring() < b.path().wstring();
        });
        for (const auto& e : items) {
            auto rel = fs::relative(e.path(), g.projectDir).wstring();
            std::wstring row = e.is_directory() ? L"[DIR] " : L"      ";
            row += rel;
            int index = (int)SendMessageW(g.explorer, LB_ADDSTRING, 0, (LPARAM)row.c_str());
            if (index >= (int)g.explorerItems.size()) g.explorerItems.resize((size_t)index + 1);
            g.explorerItems[(size_t)index] = e.path();
        }
        Status(L"Explorer refreshed: " + std::to_wstring(items.size()) + L" items");
    } catch (...) {
        SendMessageW(g.explorer, LB_ADDSTRING, 0, (LPARAM)L"<scan failed>");
        g.explorerItems.emplace_back();
    }
}

static void OpenProjectPath(const fs::path& dir) {
    if (dir.empty() || !fs::is_directory(dir)) return;
    if (!ConfirmDiscardChanges()) return;
    g.projectDir = fs::absolute(dir);
    g.currentFile.clear();
    SetWindowTextAndClearDirty(g.editor, L"// Project opened in DEIIG\r\n\r\n");
    TouchRecentProject(g.projectDir);
    RefreshExplorer();
    SetWorkingDirectoryForTerminal();
    AppendTerminal(L"\r\n[DEIIG] Project: " + g.projectDir.wstring() + L"\r\n");
    UpdateTitle();
    Status(L"Project opened: " + g.projectDir.wstring());
}

static void OpenProject() {
    fs::path dir = ChooseFolder();
    if (!dir.empty()) OpenProjectPath(dir);
}

static void NewFile() {
    if (!ConfirmDiscardChanges()) return;
    g.currentFile.clear();
    g.diggCodeMode = true;
    SetWindowTextAndClearDirty(g.editor, L"// DEIIGCode new file\r\n\r\nfn main() {\r\n    print(\"Hello, DEIIG\");\r\n}\r\n");
    HighlightDiggSyntax(g.editor);
    UpdateTitle();
    Status(L"New unsaved file");
    SetFocus(g.editor);
}

static void NewFolder() {
    if (g.projectDir.empty()) {
        MessageBoxW(g.hwnd, L"Open a project first.", L"DEIIG", MB_ICONINFORMATION);
        return;
    }
    wchar_t name[MAX_PATH] = L"new-folder";
    fs::path target = g.projectDir / name;
    for (int i = 2; fs::exists(target); ++i) target = g.projectDir / (std::wstring(name) + L"-" + std::to_wstring(i));
    std::error_code ec;
    fs::create_directories(target, ec);
    if (ec) MessageBoxW(g.hwnd, L"Could not create folder.", L"DEIIG", MB_ICONERROR);
    RefreshExplorer();
}

static void OpenEditorFile() {
    fs::path file = ChooseFile(L"Source/text\0*.cpp;*.h;*.hpp;*.c;*.diggcode;*.txt;*.md;*.json;*.toml;*.cmake;*.py;*.rs\0All files\0*.*\0");
    if (!file.empty()) LoadEditor(file);
}

static void OpenBrowser() {
    if (ShellExecuteW(g.hwnd, L"open", L"https://www.google.com", nullptr, nullptr, SW_SHOWNORMAL) > 32) {
        Status(L"Opened default browser. WebView2 embedding is planned.");
    } else {
        Status(L"Unable to launch browser.");
    }
}

static void RevealCurrent() {
    fs::path target = g.currentFile.empty() ? g.projectDir : g.currentFile;
    if (target.empty()) {
        MessageBoxW(g.hwnd, L"Open a project or file first.", L"DEIIG", MB_ICONINFORMATION);
        return;
    }
    if (fs::is_directory(target)) {
        ShellExecuteW(g.hwnd, L"open", target.wstring().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        return;
    }
    std::wstring args = L"/select,\"" + target.wstring() + L"\"";
    ShellExecuteW(g.hwnd, L"open", L"explorer.exe", args.c_str(), nullptr, SW_SHOWNORMAL);
}

static BOOL CALLBACK FindOwnedWindow(HWND hwnd, LPARAM lp) {
    auto* data = reinterpret_cast<std::pair<DWORD, HWND>*>(lp);
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid == data->first && IsWindowVisible(hwnd) && GetWindow(hwnd, GW_OWNER) == nullptr) {
        data->second = hwnd;
        return FALSE;
    }
    return TRUE;
}

static void LaunchExe() {
    fs::path exe = ChooseFile(L"Executable\0*.exe\0All files\0*.*\0");
    if (exe.empty()) return;

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    std::wstring command = L"\"" + exe.wstring() + L"\"";
    std::vector<wchar_t> buffer(command.begin(), command.end());
    buffer.push_back(L'\0');

    if (!CreateProcessW(nullptr, buffer.data(), nullptr, nullptr, FALSE, 0, nullptr,
                        exe.parent_path().c_str(), &si, &pi)) {
        MessageBoxW(g.hwnd, L"Unable to start executable.", L"DEIIG EXE Browser", MB_ICONERROR);
        return;
    }

    AppendTerminal(L"\r\n[EXE] " + exe.wstring() + L"\r\n");
    HWND child = nullptr;
    for (int i = 0; i < 25 && !child; ++i) {
        Sleep(100);
        std::pair<DWORD, HWND> data{pi.dwProcessId, nullptr};
        EnumWindows(FindOwnedWindow, (LPARAM)&data);
        child = data.second;
    }

    if (child) {
        SetParent(child, g.hwnd);
        LONG_PTR style = GetWindowLongPtrW(child, GWL_STYLE);
        style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU | WS_POPUP);
        style |= WS_CHILD;
        SetWindowLongPtrW(child, GWL_STYLE, style);
        RECT rc{};
        GetClientRect(g.hwnd, &rc);
        SetWindowPos(child, HWND_TOP, 360, 60, std::max(300L, rc.right - 380L), std::max(250L, rc.bottom - 140L), SWP_SHOWWINDOW);
        Status(L"EXE Browser: embedded window active (experimental)");
    } else {
        Status(L"EXE started; no embeddable top-level window was found.");
    }

    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
}

static void CmdReader(HANDLE stdoutRead) {
    char buf[4096];
    DWORD got = 0;
    while (g.cmdRunning) {
        if (!ReadFile(stdoutRead, buf, sizeof(buf), &got, nullptr) || got == 0) break;
        std::string bytes(buf, buf + got);
        int n = MultiByteToWideChar(CP_OEMCP, 0, bytes.data(), (int)bytes.size(), nullptr, 0);
        if (n <= 0) continue;
        std::wstring text(n, L'\0');
        MultiByteToWideChar(CP_OEMCP, 0, bytes.data(), (int)bytes.size(), text.data(), n);
        auto* p = new std::wstring(std::move(text));
        PostMessageW(g.hwnd, WM_APPEND_TERM, 0, (LPARAM)p);
    }
    CloseHandle(stdoutRead);
}

static bool StartCmd() {
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    HANDLE outRead = nullptr, outWrite = nullptr, inRead = nullptr, inWrite = nullptr;
    if (!CreatePipe(&outRead, &outWrite, &sa, 0)) return false;
    if (!CreatePipe(&inRead, &inWrite, &sa, 0)) { CloseHandle(outRead); CloseHandle(outWrite); return false; }
    if (!SetHandleInformation(outRead, HANDLE_FLAG_INHERIT, 0)) { CloseHandle(outRead); CloseHandle(outWrite); CloseHandle(inRead); CloseHandle(inWrite); return false; }
    if (!SetHandleInformation(inWrite, HANDLE_FLAG_INHERIT, 0)) { CloseHandle(outRead); CloseHandle(outWrite); CloseHandle(inRead); CloseHandle(inWrite); return false; }

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = inRead;
    si.hStdOutput = outWrite;
    si.hStdError = outWrite;

    wchar_t cmd[] = L"cmd.exe /Q";
    BOOL ok = CreateProcessW(nullptr, cmd, nullptr, nullptr, TRUE, CREATE_NO_WINDOW,
                             nullptr, nullptr, &si, &g.cmdPi);
    CloseHandle(outWrite);
    CloseHandle(inRead);
    if (!ok) {
        CloseHandle(outRead);
        CloseHandle(inWrite);
        return false;
    }

    g.cmdIn = inWrite;
    g.cmdRunning = true;
    g.cmdReader = std::thread(CmdReader, outRead);
    if (!g.projectDir.empty()) SetWorkingDirectoryForTerminal();
    return true;
}

static void StopCmd() {
    g.cmdRunning = false;
    if (g.cmdIn) { CloseHandle(g.cmdIn); g.cmdIn = nullptr; }
    if (g.cmdPi.hProcess) {
        TerminateProcess(g.cmdPi.hProcess, 0);
        CloseHandle(g.cmdPi.hProcess);
        CloseHandle(g.cmdPi.hThread);
        g.cmdPi = {};
    }
    if (g.cmdReader.joinable()) g.cmdReader.join();
}

static void AddHistory(const std::wstring& command) {
    if (command.empty()) return;
    if (g.commandHistory.empty() || g.commandHistory.back() != command) g.commandHistory.push_back(command);
    if (g.commandHistory.size() > 100) g.commandHistory.erase(g.commandHistory.begin());
    g.historyPos = -1;
}

static void HistoryMove(int delta) {
    if (g.commandHistory.empty()) return;
    if (g.historyPos < 0) g.historyPos = (int)g.commandHistory.size();
    g.historyPos += delta;
    g.historyPos = std::clamp(g.historyPos, 0, (int)g.commandHistory.size());
    if (g.historyPos == (int)g.commandHistory.size()) {
        SetWindowTextW(g.termInput, L"");
    } else {
        SetWindowTextW(g.termInput, g.commandHistory[(size_t)g.historyPos].c_str());
        SendMessageW(g.termInput, EM_SETSEL, -1, -1);
    }
}

static void SendCmd(const std::wstring& command) {
    if (!g.cmdIn || command.empty()) return;
    AddHistory(command);
    std::wstring line = command + L"\r\n";
    int n = WideCharToMultiByte(CP_OEMCP, 0, line.data(), (int)line.size(), nullptr, 0, nullptr, nullptr);
    if (n <= 0) return;
    std::string bytes(n, '\0');
    WideCharToMultiByte(CP_OEMCP, 0, line.data(), (int)line.size(), bytes.data(), n, nullptr, nullptr);
    DWORD written = 0;
    std::lock_guard<std::mutex> lock(g.cmdWriteMutex);
    WriteFile(g.cmdIn, bytes.data(), (DWORD)bytes.size(), &written, nullptr);
}

static void BuildProject() {
    if (g.projectDir.empty()) {
        MessageBoxW(g.hwnd, L"Open a project first.", L"DEIIG Build", MB_ICONINFORMATION);
        return;
    }
    if (g.editorDirty) SaveEditor();
    AppendTerminal(L"\r\n[DEIIG] Build started...\r\n");
    SendCmd(L"cmake -S . -B build && cmake --build build --config Release");
    Status(L"Build command sent to terminal.");
}

static fs::path GuessRunTarget() {
    if (g.projectDir.empty()) return {};
    if (!g.currentFile.empty() && g.currentFile.extension() == L".exe") return g.currentFile;
    fs::path release = g.projectDir / L"build" / L"Release";
    if (fs::exists(release)) {
        for (auto const& e : fs::directory_iterator(release)) {
            if (e.is_regular_file() && e.path().extension() == L".exe") return e.path();
        }
    }
    fs::path flatBuild = g.projectDir / L"build";
    if (fs::exists(flatBuild)) {
        for (auto const& e : fs::directory_iterator(flatBuild)) {
            if (e.is_regular_file() && e.path().extension() == L".exe") return e.path();
        }
    }
    return {};
}

static void RunProject() {
    if (!g.currentFile.empty() && g.currentFile.extension() == L".diggcode") {
        if (g.editorDirty) SaveEditor();
        fs::path runtime = fs::current_path() / L"DIGGRuntime.exe";
        if (!fs::exists(runtime) && !g.projectDir.empty()) runtime = g.projectDir / L"build" / L"Release" / L"DIGGRuntime.exe";
        if (!fs::exists(runtime) && !g.projectDir.empty()) runtime = g.projectDir / L"build" / L"DIGGRuntime.exe";
        if (!fs::exists(runtime)) {
            MessageBoxW(g.hwnd, L"DIGGRuntime.exe was not found. Build the project first.", L"DEIIG DIGG Runtime", MB_ICONINFORMATION);
            return;
        }
        std::wstring command = L"\"" + runtime.wstring() + L"\" \"" + g.currentFile.wstring() + L"\"";
        SendCmd(command);
        AppendTerminal(L"\r\n[DEIIG DIGG] Running: " + g.currentFile.wstring() + L"\r\n");
        return;
    }
    fs::path exe = GuessRunTarget();
    if (exe.empty()) {
        MessageBoxW(g.hwnd, L"No executable found. Build the project first or open a .diggcode file.", L"DEIIG Run", MB_ICONINFORMATION);
        return;
    }
    std::wstring command = L"\"" + exe.wstring() + L"\"";
    SendCmd(command);
    AppendTerminal(L"\r\n[DEIIG] Running: " + exe.wstring() + L"\r\n");
}

static void ApplyFont(HWND h, HFONT font) {
    if (h) SendMessageW(h, WM_SETFONT, (WPARAM)font, TRUE);
}

static HWND MakeButton(HWND parent, int id, const wchar_t* text) {
    return CreateWindowExW(0, L"BUTTON", text, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                           0, 0, 80, 28, parent, (HMENU)(INT_PTR)id, GetModuleHandleW(nullptr), nullptr);
}

static void CreateUI(HWND hwnd) {
    LoadLibraryW(L"Msftedit.dll");
    g.uiFont = CreateFontW(-15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                           DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                           CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
    g.monoFont = CreateFontW(-15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                             DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             CLEARTYPE_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");

    g.title = CreateWindowExW(0, L"STATIC", L"DEIIG", WS_CHILD | WS_VISIBLE | SS_LEFT,
        12, 10, 900, 24, hwnd, (HMENU)IDC_TITLE, nullptr, nullptr);
    ApplyFont(g.title, g.uiFont);

    const int ids[] = {IDC_NEW, IDC_OPEN_PROJECT, IDC_OPEN_FILE, IDC_SAVE, IDC_BUILD, IDC_RUN, IDC_OPEN_BROWSER, IDC_RUN_EXE, IDC_NEW_FOLDER, IDC_REFRESH, IDC_REVEAL,
                       IDC_PREVIEW, IDC_TASKS, IDC_AI, IDC_PROBLEMS, IDC_SPLIT, IDC_INSPECT, IDC_LIB, IDC_GOOGLE, IDC_BING};
    const wchar_t* labels[] = {L"New", L"Project", L"Open", L"Save", L"Build", L"Run", L"Browser", L"EXE", L"Folder", L"Refresh", L"Reveal",
                               L"Preview", L"Tasks", L"AI", L"Problems", L"Split", L"Inspect", L"Lib", L"Google", L"Bing"};
    for (int i = 0; i < 20; ++i) ApplyFont(MakeButton(hwnd, ids[i], labels[i]), g.uiFont);

    g.explorer = CreateWindowExW(WS_EX_CLIENTEDGE, L"LISTBOX", nullptr,
        WS_CHILD | WS_VISIBLE | LBS_NOINTEGRALHEIGHT | WS_VSCROLL | LBS_NOTIFY,
        0, 0, 250, 300, hwnd, (HMENU)IDC_EXPLORER, nullptr, nullptr);
    g.editor = CreateWindowExW(WS_EX_CLIENTEDGE, MSFTEDIT_CLASS, nullptr,
        WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOOLEDRAGDROP,
        0, 0, 500, 300, hwnd, (HMENU)IDC_EDITOR, nullptr, nullptr);
    SendMessageW(g.editor, EM_SETEVENTMASK, 0, (LPARAM)(SendMessageW(g.editor, EM_GETEVENTMASK, 0, 0) | ENM_SELCHANGE));
    g.terminal = CreateWindowExW(WS_EX_CLIENTEDGE, MSFTEDIT_CLASS, nullptr,
        WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
        0, 0, 700, 180, hwnd, (HMENU)IDC_TERMINAL, nullptr, nullptr);
    g.termInput = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", nullptr,
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        0, 0, 500, 28, hwnd, (HMENU)IDC_TERM_INPUT, nullptr, nullptr);
    g.status = CreateWindowExW(0, L"STATIC", L"Ready.", WS_CHILD | WS_VISIBLE | SS_LEFT,
        0, 0, 700, 24, hwnd, (HMENU)IDC_STATUS, nullptr, nullptr);

    ApplyFont(g.explorer, g.uiFont);
    ApplyFont(g.editor, g.monoFont);
    ApplyFont(g.terminal, g.monoFont);
    ApplyFont(g.termInput, g.monoFont);
    ApplyFont(g.status, g.uiFont);

    g_oldTermProc = (WNDPROC)SetWindowLongPtrW(g.termInput, GWLP_WNDPROC, (LONG_PTR)TermInputProc);
    g_oldEditorProc = (WNDPROC)SetWindowLongPtrW(g.editor, GWLP_WNDPROC, (LONG_PTR)EditorProc);

    SetWindowTextAndClearDirty(g.editor, L"// Welcome to DEIIG 0.10\r\n// Files ending in .diggcode use DEIIG syntax highlighting.\r\n\r\nfn main() {\r\n    print(\"Hello, DEIIG\");\r\n}\r\n");
    SetWindowTextW(g.terminal, L"DEIIG 0.10 terminal — cmd.exe backend\r\n");
    LoadRecentProjects();
    RefreshExplorer();
    if (!StartCmd()) AppendTerminal(L"[DEIIG] Failed to start cmd.exe\r\n");
    else AppendTerminal(L"[DEIIG] Terminal ready. Up/Down = history, Enter = run.\r\n");
    UpdateTitle();
}

static LRESULT CALLBACK TermInputProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    if (msg == WM_KEYDOWN) {
        if (w == VK_RETURN) {
            const std::wstring command = GetText(hwnd);
            if (!command.empty()) {
                AppendTerminal(L"\r\n> " + command + L"\r\n");
                SendCmd(command);
            }
            SetWindowTextW(hwnd, L"");
            g.historyPos = -1;
            return 0;
        }
        if (w == VK_UP) { HistoryMove(-1); return 0; }
        if (w == VK_DOWN) { HistoryMove(1); return 0; }
        if ((GetKeyState(VK_CONTROL) & 0x8000) && w == 'L') {
            SetWindowTextW(hwnd, L"");
            return 0;
        }
    }
    return CallWindowProcW(g_oldTermProc, hwnd, msg, w, l);
}


struct DiggSpan {
    LONG start;
    LONG len;
    COLORREF color;
    COLORREF back;
    bool bold;
    bool underline;
};

static void ApplySpan(HWND hwnd, const DiggSpan& span) {
    CHARFORMAT2W cf{};
    cf.cbSize = sizeof(cf);
    cf.dwMask = CFM_COLOR | CFM_BACKCOLOR | CFM_BOLD | CFM_UNDERLINE;
    cf.crTextColor = span.color;
    cf.crBackColor = span.back;
    cf.dwEffects = (span.bold ? CFE_BOLD : 0) | (span.underline ? CFE_UNDERLINE : 0);
    CHARRANGE range{span.start, span.start + span.len};
    SendMessageW(hwnd, EM_EXSETSEL, 0, (LPARAM)&range);
    SendMessageW(hwnd, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM)&cf);
}

static bool IsDiggIdentStart(wchar_t c) { return std::iswalpha(c) || c == L'_'; }
static bool IsDiggIdent(wchar_t c) { return std::iswalnum(c) || c == L'_'; }

static bool IsDiggKeyword(const std::wstring& w) {
    static const wchar_t* words[] = {
        L"fn", L"let", L"var", L"const", L"if", L"else", L"while", L"for", L"return",
        L"break", L"continue", L"match", L"struct", L"class", L"import", L"include", L"use",
        L"true", L"false", L"null", L"and", L"or", L"not", L"in", L"as", L"async", L"await",
        L"try", L"catch", L"throw", L"defer", L"pub", L"private", L"new", L"delete"
    };
    for (auto* x : words) if (w == x) return true;
    return false;
}

static bool IsDiggBuiltin(const std::wstring& w) {
    static const wchar_t* words[] = {
        L"print", L"input", L"read", L"write", L"len", L"type", L"range", L"spawn", L"sleep",
        L"exit", L"open", L"close", L"system", L"log", L"error"
    };
    for (auto* x : words) if (w == x) return true;
    return false;
}

static void HighlightDiggSyntax(HWND hwnd) {
    if (!hwnd || g.highlighting) return;
    g.highlighting = true;
    const std::wstring text = GetText(hwnd);
    const LONG n = (LONG)text.size();
    CHARRANGE oldSel{};
    SendMessageW(hwnd, EM_EXGETSEL, 0, (LPARAM)&oldSel);
    SendMessageW(hwnd, WM_SETREDRAW, FALSE, 0);

    if (n > 0) {
        CHARFORMAT2W base{};
        base.cbSize = sizeof(base);
        base.dwMask = CFM_COLOR | CFM_BACKCOLOR | CFM_BOLD | CFM_UNDERLINE;
        base.crTextColor = RGB(25,25,25);
        base.crBackColor = RGB(255,255,255);
        base.dwEffects = 0;
        CHARRANGE all{0, n};
        SendMessageW(hwnd, EM_EXSETSEL, 0, (LPARAM)&all);
        SendMessageW(hwnd, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM)&base);
    }

    std::vector<DiggSpan> spans;
    std::vector<std::pair<wchar_t, LONG>> brackets;
    size_t i = 0;
    while (i < text.size()) {
        const wchar_t c = text[i];
        if (c == L'\r' || c == L'\n') { ++i; continue; }

        // Line comment
        if (c == L'/' && i + 1 < text.size() && text[i+1] == L'/') {
            size_t start=i; i+=2;
            while (i<text.size() && text[i]!=L'\r' && text[i]!=L'\n') ++i;
            spans.push_back({(LONG)start,(LONG)(i-start),RGB(0,125,70),RGB(245,255,248),false,false});
            continue;
        }
        // Block comment
        if (c == L'/' && i + 1 < text.size() && text[i+1] == L'*') {
            size_t start=i; i+=2; bool closed=false;
            while (i + 1 < text.size()) {
                if (text[i] == L'*' && text[i+1] == L'/') { i+=2; closed=true; break; }
                ++i;
            }
            if (!closed) {
                spans.push_back({(LONG)start,(LONG)(text.size()-start),RGB(210,0,0),RGB(255,235,235),false,true});
                break;
            }
            spans.push_back({(LONG)start,(LONG)(i-start),RGB(0,125,70),RGB(245,255,248),false,false});
            continue;
        }
        // String / char literal
        if (c == L'\"' || c == L'\'') {
            const wchar_t quote=c; size_t start=i++; bool closed=false;
            while (i<text.size()) {
                if (text[i] == L'\\') { i += (i+1<text.size()?2:1); continue; }
                if (text[i] == quote) { ++i; closed=true; break; }
                if (text[i] == L'\r' || text[i] == L'\n') break;
                ++i;
            }
            if (!closed) spans.push_back({(LONG)start,(LONG)(i-start),RGB(210,0,0),RGB(255,235,235),false,true});
            else spans.push_back({(LONG)start,(LONG)(i-start),RGB(155,80,0),RGB(255,249,235),false,false});
            continue;
        }
        // Number
        if (std::iswdigit(c) || (c==L'.' && i+1<text.size() && std::iswdigit(text[i+1]))) {
            size_t start=i;
            while (i<text.size() && (std::iswalnum(text[i]) || text[i]==L'.' || text[i]==L'_')) ++i;
            spans.push_back({(LONG)start,(LONG)(i-start),RGB(70,80,180),RGB(248,248,255),false,false});
            continue;
        }
        // Identifier / keyword / builtin
        if (IsDiggIdentStart(c)) {
            size_t start=i++;
            while (i<text.size() && IsDiggIdent(text[i])) ++i;
            const std::wstring word = text.substr(start, i-start);
            if (IsDiggKeyword(word)) spans.push_back({(LONG)start,(LONG)word.size(),RGB(120,45,170),RGB(250,244,255),true,false});
            else if (IsDiggBuiltin(word)) spans.push_back({(LONG)start,(LONG)word.size(),RGB(0,105,170),RGB(240,250,255),true,false});
            continue;
        }

        if (c==L'(' || c==L'[' || c==L'{') brackets.emplace_back(c,(LONG)i);
        else if (c==L')' || c==L']' || c==L'}') {
            wchar_t want = c==L')'?L'(':c==L']'?L'[':L'{';
            if (brackets.empty() || brackets.back().first != want) {
                spans.push_back({(LONG)i,1,RGB(210,0,0),RGB(255,235,235),true,true});
            } else {
                brackets.pop_back();
            }
        }
        // DiggCode intentionally rejects backticks and raw control escapes as invalid.
        if (c == L'`' || c == L'\x00') spans.push_back({(LONG)i,1,RGB(210,0,0),RGB(255,235,235),true,true});
        ++i;
    }

    // Unmatched opening brackets are errors.
    for (const auto& b : brackets) spans.push_back({b.second,1,RGB(210,0,0),RGB(255,235,235),true,true});

    for (const auto& span : spans) ApplySpan(hwnd, span);

    SendMessageW(hwnd, EM_EXSETSEL, 0, (LPARAM)&oldSel);
    SendMessageW(hwnd, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(hwnd, nullptr, TRUE);
    UpdateWindow(hwnd);
    HighlightDiggBracketMatch(hwnd);
    g.highlighting = false;
}

static void HighlightDiggBracketMatch(HWND hwnd) {
    if (!hwnd) return;
    const std::wstring text = GetText(hwnd);
    if (text.empty()) return;
    CHARRANGE sel{};
    SendMessageW(hwnd, EM_EXGETSEL, 0, (LPARAM)&sel);
    LONG pos = sel.cpMin;
    LONG candidates[2] = {pos - 1, pos};
    LONG bracketPos = -1;
    wchar_t openChar = 0, closeChar = 0;
    for (LONG p : candidates) {
        if (p < 0 || p >= (LONG)text.size()) continue;
        wchar_t c=text[(size_t)p];
        if (c==L'('||c==L'['||c==L'{') { bracketPos=p; openChar=c; closeChar=c==L'('?L')':c==L'['?L']':L'}'; break; }
        if (c==L')'||c==L']'||c==L'}') { bracketPos=p; closeChar=c; openChar=c==L')'?L'(':c==L']'?L'[':L'{'; break; }
    }
    if (bracketPos < 0) return;
    int dir = (text[(size_t)bracketPos] == openChar) ? 1 : -1;
    int depth=0; LONG match=-1;
    for (LONG p=bracketPos; p>=0 && p<(LONG)text.size(); p+=dir) {
        wchar_t c=text[(size_t)p];
        if (c==openChar) depth++;
        else if (c==closeChar) { depth--; if (depth==0) { match=p; break; } }
    }
    if (match<0) return;
    for (LONG p : {bracketPos, match}) {
        CHARFORMAT2W cf{}; cf.cbSize=sizeof(cf); cf.dwMask=CFM_COLOR|CFM_BACKCOLOR|CFM_BOLD|CFM_UNDERLINE;
        cf.crTextColor=RGB(0,0,0); cf.crBackColor=RGB(255,225,70); cf.dwEffects=CFE_BOLD;
        CHARRANGE r{p,p+1}; SendMessageW(hwnd,EM_EXSETSEL,0,(LPARAM)&r); SendMessageW(hwnd,EM_SETCHARFORMAT,SCF_SELECTION,(LPARAM)&cf);
    }
    SendMessageW(hwnd, EM_EXSETSEL, 0, (LPARAM)&sel);
}

static void InsertAutoPair(HWND hwnd, wchar_t open, wchar_t close) {
    std::wstring pair;
    pair.push_back(open);
    pair.push_back(close);
    SendMessageW(hwnd, EM_REPLACESEL, TRUE, (LPARAM)pair.c_str());
    CHARRANGE sel{};
    SendMessageW(hwnd, EM_EXGETSEL, 0, (LPARAM)&sel);
    const LONG caret = sel.cpMax - 1;
    SendMessageW(hwnd, EM_SETSEL, caret, caret);
}

static LRESULT CALLBACK EditorProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    if (msg == WM_KEYDOWN) {
        const bool ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
        if (ctrl && w == 'S') { SaveEditor(); return 0; }
        if (IsDiggCodeMode()) {
            if (w == VK_RETURN) {
                LRESULT result = CallWindowProcW(g_oldEditorProc, hwnd, msg, w, l);
                PostMessageW(g.hwnd, WM_HIGHLIGHT_EDITOR, 0, 0);
                return result;
            }
        }
    }
    if (msg == WM_CHAR && IsDiggCodeMode()) {
        const wchar_t c = (wchar_t)w;
        if (c == L'(' || c == L'[' || c == L'{') {
            InsertAutoPair(hwnd, c, c==L'('?L')':c==L'['?L']':L'}');
            PostMessageW(g.hwnd, WM_HIGHLIGHT_EDITOR, 0, 0);
            return 0;
        }
        if (c == L')' || c == L']' || c == L'}') {
            CHARRANGE sel{}; SendMessageW(hwnd, EM_EXGETSEL, 0, (LPARAM)&sel);
            const std::wstring text = GetText(hwnd);
            if (sel.cpMin == sel.cpMax && sel.cpMin < (LONG)text.size() && text[(size_t)sel.cpMin] == c) {
                SendMessageW(hwnd, EM_SETSEL, sel.cpMin + 1, sel.cpMin + 1);
                PostMessageW(g.hwnd, WM_HIGHLIGHT_EDITOR, 0, 0);
                return 0;
            }
        }
    }
    if (msg == WM_KEYUP || msg == WM_LBUTTONUP || msg == WM_RBUTTONUP) {
        if (IsDiggCodeMode()) PostMessageW(g.hwnd, WM_HIGHLIGHT_EDITOR, 0, 0);
    }
    if (msg == WM_CHAR && w == L'\t') return 0;
    return CallWindowProcW(g_oldEditorProc, hwnd, msg, w, l);
}

static void Layout(HWND hwnd) {
    RECT r{}; GetClientRect(hwnd, &r);
    const int margin = 10;
    const int top = 74;
    const int leftW = 290;
    const int statusH = 22;
    const int inputH = 29;
    const int terminalH = std::max(170, r.bottom / 4);
    const int gap = 7;
    const int contentH = std::max(180, r.bottom - top - statusH - inputH - terminalH - margin * 2 - gap * 3);
    const int rightX = margin + leftW + gap;
    const int rightW = std::max(360, r.right - rightX - margin);

    const int row1Ids[] = {IDC_NEW, IDC_OPEN_PROJECT, IDC_OPEN_FILE, IDC_SAVE, IDC_BUILD, IDC_RUN, IDC_OPEN_BROWSER, IDC_RUN_EXE, IDC_NEW_FOLDER, IDC_REFRESH, IDC_REVEAL};
    const int row1W[] = {55,82,70,65,65,60,78,66,70,68,65};
    int x = margin;
    for (size_t i = 0; i < std::size(row1Ids); ++i) {
        SetWindowPos(GetDlgItem(hwnd, row1Ids[i]), nullptr, x, 8, row1W[i], 28, SWP_NOZORDER);
        x += row1W[i] + 4;
    }
    const int row2Ids[] = {IDC_PREVIEW, IDC_TASKS, IDC_AI, IDC_PROBLEMS, IDC_SPLIT, IDC_INSPECT, IDC_LIB, IDC_GOOGLE, IDC_BING};
    const int row2W[] = {75,65,55,82,58,68,55,70,60};
    x = margin;
    for (size_t i = 0; i < std::size(row2Ids); ++i) {
        SetWindowPos(GetDlgItem(hwnd, row2Ids[i]), nullptr, x, 40, row2W[i], 28, SWP_NOZORDER);
        x += row2W[i] + 4;
    }
    SetWindowPos(g.title, nullptr, x + 8, 40, std::max(220, r.right - x - 20), 28, SWP_NOZORDER);

    SetWindowPos(g.explorer, nullptr, margin, top, leftW, contentH + terminalH + inputH + gap, SWP_NOZORDER);
    if (!g.splitView || !g.editor2) {
        SetWindowPos(g.editor, nullptr, rightX, top, rightW, contentH, SWP_NOZORDER);
    } else {
        const int half = (rightW - gap) / 2;
        SetWindowPos(g.editor, nullptr, rightX, top, half, contentH, SWP_NOZORDER);
        SetWindowPos(g.editor2, nullptr, rightX + half + gap, top, rightW - half - gap, contentH, SWP_NOZORDER);
    }
    const int termY = top + contentH + gap;
    SetWindowPos(g.terminal, nullptr, rightX, termY, rightW, terminalH, SWP_NOZORDER);
    SetWindowPos(g.termInput, nullptr, rightX, termY + terminalH + 3, rightW, inputH, SWP_NOZORDER);
    SetWindowPos(g.status, nullptr, margin, r.bottom - statusH, r.right - margin * 2, statusH, SWP_NOZORDER);
}

static void OnExplorerDoubleClick() {
    int index = (int)SendMessageW(g.explorer, LB_GETCURSEL, 0, 0);
    if (index < 0 || index >= (int)g.explorerItems.size()) return;
    fs::path p = g.explorerItems[(size_t)index];
    if (p.empty()) return;
    if (fs::is_directory(p)) {
        ShellExecuteW(g.hwnd, L"open", p.wstring().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        return;
    }
    LoadEditor(p);
}

static void FocusTerminal() {
    SetFocus(g.termInput);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE:
        g.hwnd = hwnd;
        CreateUI(hwnd);
        return 0;
    case WM_SIZE:
        Layout(hwnd);
        return 0;
    case WM_NOTIFY: {
        auto* hdr = reinterpret_cast<NMHDR*>(l);
        if (hdr && hdr->hwndFrom == g.editor && hdr->code == EN_SELCHANGE && IsDiggCodeMode() && !g.highlighting) {
            PostMessageW(hwnd, WM_HIGHLIGHT_EDITOR, 0, 0);
        }
        return 0;
    }
    case WM_HIGHLIGHT_EDITOR:
        if (IsDiggCodeMode() && !g.highlighting) HighlightDiggSyntax(g.editor);
        return 0;
    case WM_COMMAND:
        if (HIWORD(w) == EN_CHANGE && LOWORD(w) == IDC_EDITOR) {
            if (!g.suppressEditorDirty && !g.editorDirty) {
                g.editorDirty = true;
                UpdateTitle();
            }
            if (IsDiggCodeMode() && !g.suppressEditorDirty) PostMessageW(hwnd, WM_HIGHLIGHT_EDITOR, 0, 0);
            return 0;
        }
        if (HIWORD(w) == LBN_DBLCLK && LOWORD(w) == IDC_EXPLORER) {
            OnExplorerDoubleClick();
        } else if (HIWORD(w) == BN_CLICKED || HIWORD(w) == 1 || HIWORD(w) == 0) {
            switch (LOWORD(w)) {
            case IDC_NEW: NewFile(); break;
            case IDC_OPEN_PROJECT: OpenProject(); break;
            case IDC_OPEN_FILE: OpenEditorFile(); break;
            case IDC_SAVE: SaveEditor(); break;
            case IDC_BUILD: BuildProject(); break;
            case IDC_RUN: RunProject(); break;
            case IDC_OPEN_BROWSER: OpenBrowser(); break;
            case IDC_RUN_EXE: LaunchExe(); break;
            case IDC_NEW_FOLDER: NewFolder(); break;
            case IDC_REFRESH: RefreshExplorer(); break;
            case IDC_REVEAL: RevealCurrent(); break;
            case IDC_FOCUS_TERMINAL: FocusTerminal(); break;
            case IDC_PREVIEW: PreviewCurrent(); break;
            case IDC_TASKS: RunTask(); break;
            case IDC_AI: AIWorkspace(); break;
            case IDC_PROBLEMS: ShowProblems(); break;
            case IDC_SPLIT: ToggleSplitView(); break;
            case IDC_INSPECT: InspectExe(); break;
            case IDC_LIB: InstallLibrary(); break;
            case IDC_GOOGLE: WebSearch(L"Google"); break;
            case IDC_BING: WebSearch(L"Bing"); break;
            }
        }
        return 0;
    case WM_APPEND_TERM: {
        auto* p = reinterpret_cast<std::wstring*>(l);
        if (p) { AppendTerminal(*p); delete p; }
        return 0;
    }
    case WM_CLOSE:
        if (!ConfirmDiscardChanges()) return 0;
        StopCmd();
        if (g.runPi.hProcess) {
            TerminateProcess(g.runPi.hProcess, 0);
            CloseHandle(g.runPi.hProcess);
            CloseHandle(g.runPi.hThread);
            g.runPi = {};
        }
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        if (g.uiFont) DeleteObject(g.uiFont);
        if (g.monoFont) DeleteObject(g.monoFont);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, w, l);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow) {
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&icc);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.hInstance = hInstance;
    wc.lpfnWndProc = WndProc;
    wc.lpszClassName = APP_CLASS;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    if (!RegisterClassExW(&wc)) return 1;

    HWND hwnd = CreateWindowExW(0, APP_CLASS, L"DEIIG — The Development Environment Is Insanely Good",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT, CW_USEDEFAULT, 1500, 900,
        nullptr, nullptr, hInstance, nullptr);
    if (!hwnd) { CoUninitialize(); return 1; }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    ACCEL accelerators[] = {
        {FVIRTKEY | FCONTROL, 'S', IDC_SAVE},
        {FVIRTKEY | FCONTROL, 'N', IDC_NEW},
        {FVIRTKEY | FCONTROL, 'O', IDC_OPEN_FILE},
        {FVIRTKEY | FCONTROL | FSHIFT, 'O', IDC_OPEN_PROJECT},
        {FVIRTKEY | FCONTROL, 'L', IDC_FOCUS_TERMINAL},
        {FVIRTKEY | FCONTROL, 'B', IDC_BUILD},
        {FVIRTKEY, VK_F5, IDC_RUN},
    };
    HACCEL hAccel = CreateAcceleratorTableW(accelerators, (int)(sizeof(accelerators) / sizeof(accelerators[0])));

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (!hAccel || !TranslateAcceleratorW(hwnd, hAccel, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    if (hAccel) DestroyAcceleratorTable(hAccel);

    CoUninitialize();
    return (int)msg.wParam;
}
